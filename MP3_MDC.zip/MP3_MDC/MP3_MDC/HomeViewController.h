//
//  HomeViewController.h
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AFNetworking/AFNetworking.h>
@class CellCustemTableViewCell;

@interface HomeViewController : UIViewController<NSURLConnectionDataDelegate>

@property (nonatomic, assign) UIImageView *loadImageView;
@property (assign, nonatomic) NSMutableArray *mangLinkNhac;
@property (assign, nonatomic) NSMutableArray *arrTracks;
@property (assign, nonatomic) UIBarButtonItem *btPlay;
@property (assign, nonatomic) UIActivityIndicatorView *indicator;
-(void) setBarButton;
@end
