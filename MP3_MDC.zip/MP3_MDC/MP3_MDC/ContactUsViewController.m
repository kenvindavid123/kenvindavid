//
//  ContactUsViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 6/10/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "ContactUsViewController.h"

@interface ContactUsViewController ()<UITableViewDelegate, UITableViewDataSource>{
    UITableView *table;
}

@end

@implementation ContactUsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    table = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    [table release];
    // Do any additional setup after loading the view.
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 55;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [table dequeueReusableCellWithIdentifier:@"mycell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
    }
    if (indexPath.row == 0) {
        cell.imageView.image = [UIImage imageNamed:@"bluet.jpeg"];
        cell.textLabel.text = @"Bluetooth";
    }
    if (indexPath.row == 1) {
        cell.imageView.image = [UIImage imageNamed:@"email1.png"];
        cell.textLabel.text = @"Email";
    }
    if (indexPath.row == 2) {
        cell.imageView.image = [UIImage imageNamed:@"gmail.jpeg"];
        cell.textLabel.text = @"Gmail";
    }
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
