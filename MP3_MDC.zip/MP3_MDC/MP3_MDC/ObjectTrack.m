//
//  ObjectTrack.m
//  MP3_MDC
//
//  Created by Duc Thanh on 5/16/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "ObjectTrack.h"

@implementation ObjectTrack
@synthesize NameSong, NameSinger, NameImage, LinkUrl;

@end
