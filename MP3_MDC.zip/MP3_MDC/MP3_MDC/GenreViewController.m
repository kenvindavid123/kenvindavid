//
//  GenreViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "GenreViewController.h"
#import "ObjectTrack.h"
#import <AFNetworking.h>
#import <AFNetworking/AFHTTPSessionManager.h>
#import <AFNetworking/UIImageView+AFNetworking.h>
#import "AppDelegate.h"
#import "ViewController.h"
#import "ListMusicViewController.h"

@interface GenreViewController ()<UITableViewDelegate, UITableViewDataSource>
{
    UILabel *lbTitle;
    UIButton *btSearch;
    UISegmentedControl *segment;
    UITableView *table;
    NSMutableArray *mangviduMusic;
    NSMutableArray *mangvdAudio;
    UITableViewCell *cell;
    UIView *viewCustem;
    BOOL modeMusic;
    NSMutableArray *arrayTrack;
    NSArray *data;
    //ObjectTrack *objectTrack1;
    NSInteger test ;
    UIActivityIndicatorView *indicator;
    
    int height;
    int width;
    
    ListMusicViewController *listMusicVC;
}

@end

@implementation GenreViewController
@synthesize tenAlbum;
#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1];
#pragma  mark --- init
-(void)loadView
{
    [super loadView];
    self.view.backgroundColor = [UIColor whiteColor];
    [self initParam];
    height = self.view.frame.size.height;
    width = self.view.frame.size.width;

    self.navigationItem.prompt = @"Genre";
    
    
    
    
    //tao segment
    segment = [[UISegmentedControl alloc] init];
    segment.frame = CGRectMake(width*6/32, height*6/52 , width*18/32, height*25/520);
    segment.tintColor = [UIColor redColor];
    [segment insertSegmentWithTitle:@"Music" atIndex:0 animated:YES];
    [segment insertSegmentWithTitle:@"Audio" atIndex:1 animated:YES];
    segment.selectedSegmentIndex = 0;
    [segment addTarget:self action:@selector(actionSegment) forControlEvents:UIControlEventValueChanged];

    self.navigationItem.titleView = segment;
    [segment release];
    
   
    
    //tao table
    table = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    [table release];

    data = [[NSArray alloc] init];
    arrayTrack = [[NSMutableArray alloc] init];
    
}

-(void)dealloc
{
    [super dealloc];
    [lbTitle release];
    [btSearch release];
    [segment release];
    [table release];
    [cell release];
    [mangviduMusic release];
    [data release];
    [arrayTrack release];
    [listMusicVC release];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //tao title
    
    
  }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self dealloc];
}

#pragma mark --table
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(modeMusic)
        return mangviduMusic.count;
    else
        return mangvdAudio.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell = [table dequeueReusableCellWithIdentifier:@"cell"];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    NSString *str = nil;
    if(modeMusic)
        str = [mangviduMusic objectAtIndex:indexPath.row];
    else
        str = [mangvdAudio objectAtIndex:indexPath.row];
    if(str != nil) {
        cell.textLabel.text = str;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [indicator setColor:[UIColor redColor]];
    [indicator setCenter:CGPointMake(width/2 -10, height*25/52)];
    if(modeMusic){
        NSString *string = [mangviduMusic objectAtIndex:indexPath.row];
        [self.view addSubview:indicator];
        [indicator startAnimating];
        [self loadJSON:string];
        self.tenAlbum = [NSString stringWithFormat:@"%@", [mangviduMusic objectAtIndex:indexPath.row]];
    }
    else{
        NSString *string = [mangvdAudio objectAtIndex:indexPath.row];
        [self.view addSubview:indicator];
        [indicator startAnimating];
        [self loadJSON:string];
        self.tenAlbum = [NSString stringWithFormat:@"%@", [mangvdAudio objectAtIndex:indexPath.row]];

    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void) initParam //khoi tao cac gia tri mang tai day
{
    mangviduMusic = [[NSMutableArray alloc] initWithObjects:@"Alternative Rock", @"Ambient", @"Classical", @"Country", @"Dance & EDM", @"Dancehall", @"Deep House", @"Diso", @"Drum & Bass", @"Dubstep", @"Electronic", @"Folk & Singer-Songwrite", @"Hip-hop & Rap", @"House", @"Indie", @"Jazz & Blues", @"Latin", @"Meal", @"Piano", @"Pop", @"R&B & Soul", @"Reggae", @"Reggaeton", @"Rok", @"Soundtrack", @"Techno", @"Trance", @"Trap", @"Triphop", @"world",nil];
    mangvdAudio = [[NSMutableArray alloc] initWithObjects:@"Audiobooks", @"Business",@"Comedy",@"Enterainment",@"Learning",@"News & Politics",@"Relligion & Spirituality", @"Science", @"Sport", @"Storytelling", @"Technolohy",     nil];
    modeMusic = YES;
    
}
-(void) actionSegment{
    if (segment.selectedSegmentIndex == 0) {
        modeMusic = YES;
    }
    if (segment.selectedSegmentIndex == 1) {
        modeMusic = NO;
    }
    [table reloadData];}

-(Boolean)loadJSON:(NSString *) s{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];

    NSString *url = [NSString stringWithFormat:@"http://api.soundcloud.com/tracks?q=%@&client_id=b97dd929a67b6331a591685c4b68bd84", s];
    url = [url stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
//    NSString *urlString = [NSString stringWithFormat:@"https://api.soundcloud.com/tracks?genres=%@&client_id=b97dd929a67b6331a591685c4b68bd84", s];
//    [urlString stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    [manager GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        data = responseObject;
        NSLog(@"%@", data);
        [self parseJSON];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"false");
    }];
    return true;
}
-(void) parseJSON{
    [arrayTrack removeAllObjects];
    for (int i = 0; i < data.count; i++) {
        NSObject *object;
        ObjectTrack *objectTrack1 = [[ObjectTrack alloc] init];
        
        object = [data objectAtIndex:i];
        NSString *title = [object valueForKey:@"title"];
        objectTrack1.NameSong = title;
        
        NSString *tencasi = [object valueForKey:@"genre"];
        objectTrack1.NameSinger = tencasi;
        
        NSString *linkAnh = [object valueForKey:@"artwork_url"];
        objectTrack1.NameImage = linkAnh;
        
        NSString *linkURL = [object valueForKey:@"stream_url"];
        objectTrack1.LinkUrl = linkURL;
        
        NSString *duration = [object valueForKey:@"duration"];
        objectTrack1.Duration = duration;
        
        [arrayTrack addObject: objectTrack1];
        [objectTrack1 release];
       
        
    }
//     NSLog(@"so luong mang la: %lu", arrayTrack.count);
    [indicator stopAnimating];
    [[AppDelegate sharedInstance] showListMusicVC];
//    if(listMusicVC == nil){
//        listMusicVC = [[ListMusicViewController alloc] init];
//    }
    //UINavigationController *naviController = [[UINavigationController alloc] initWithRootViewController:listMusicVC];
    [AppDelegate sharedInstance].listMusicVC.arrTrack = arrayTrack;
 //   listMusicVC.title = tenAlbum;
    [AppDelegate sharedInstance].listMusicVC.navigationItem.title = tenAlbum;
    //[self.navigationController pushViewController:listMusicVC animated:YES];
    
   
}

@end


