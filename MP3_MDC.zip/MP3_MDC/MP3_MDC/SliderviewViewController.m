//
//  SliderviewViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 5/31/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "SliderviewViewController.h"
//#import "Glogbal.m"


@interface SliderviewViewController (){
    UISlider *slider;
    UITextField *text;
}

@end

@implementation SliderviewViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    int height = self.view.frame.size.height;
    int width = self.view.frame.size.width;
    
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(width*7/32, height*15/52, width/2, 12 )];
    lable.text = @"Connection Timeout";
    [self.view addSubview:lable];
    
    // Do any additional setup after loading the view.
    slider = [[UISlider alloc] initWithFrame:CGRectMake((float)width/8, (float)self.view.frame.size.height/2.5, width/1.4, height/50)];
    slider.maximumValue = 60;
    slider.minimumValue = 20;
    [self.view addSubview:slider];
    [slider addTarget:self action:@selector(changeValue) forControlEvents:UIControlEventValueChanged];
    [slider release];
    
    text = [[UITextField alloc] initWithFrame:CGRectMake((float)self.view.frame.size.width/2.3, self.view.frame.size.height/2, self.view.frame.size.width/5, 10)];
    text.font = [UIFont systemFontOfSize:15];
    text.text = [NSString stringWithFormat:@"%d",(int)slider.value];
    [self.view addSubview: text];
    [text release];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) changeValue{
    text.text = [NSString stringWithFormat:@"%d", (int)slider.value];
    //timeOut = slider.value;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
