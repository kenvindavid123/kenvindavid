//
//  History.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/27/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "History.h"
#import "AppDelegate.h"
#import "CellCustemTableViewCell.h"
#import "ObjectTrack.h"
#import <AFNetworking/UIImageView+AFNetworking.h>
#import <AFNetworking/AFNetworking.h>

@interface History ()<UITableViewDelegate, UITableViewDataSource>
{
    UITableView *table;
    History *history;
    NSArray *arraydata;
    NSMutableArray *mulArray;
    NSMutableArray *arrayTrack1;
    NSArray *arrfile;
    NSMutableArray *arr;
    int heights;
}

@end

@implementation History

-(void) dealloc{
    [super dealloc];
    [arr release];
    //[arrfile release];
     [arrayTrack1 release];
    [table release];

}
-(void)loadView

{
    [super loadView];
    heights = self.view.frame.size.height;
    self.view.backgroundColor = [UIColor whiteColor];
    arrayTrack1 = [[NSMutableArray alloc] init];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"HistoryMS.txt"];
    arrfile = [[NSArray alloc] initWithContentsOfFile:filePath];
    arr = [[NSMutableArray alloc] initWithArray:arrfile];
    
    for (int i = 0; i < arr.count; i++) {
        NSMutableArray *array = [arr objectAtIndex:i];
        ObjectTrack *ob = [[ObjectTrack alloc] init];
        
        ob.NameSong = [array objectAtIndex:0];
        ob.NameSinger = [array objectAtIndex:1];
        ob.NameImage = [array objectAtIndex:2];
        
        [arrayTrack1 addObject:ob];
        
        [ob release];
        [array release];
        
    }
    
    table = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview: table];
    
    /*
    arrayTrack1 = [[NSMutableArray alloc] init];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"History";
    //[self.navigationItem setTitle:@"Back"];
//    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithTitle:@"Edit"
//                                    style:UIBarButtonItemStyleDone
//                                    target:self action:@selector(actionRightButton)];
//    self.navigationItem.rightBarButtonItem = rightButton;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"HistoryMS.txt"];
    NSArray *arrfile = [[NSArray alloc] initWithContentsOfFile:filePath];
    NSMutableArray *arr = [[NSMutableArray alloc] initWithArray:arrfile];
    
    for (int i = 0; i < arr.count; i++) {
        NSMutableArray *array = [arr objectAtIndex:i];
        ObjectTrack *ob = [[ObjectTrack alloc] init];
        
        ob.NameSong = [array objectAtIndex:0];
        ob.NameSinger = [array objectAtIndex:1];
        ob.NameImage = [array objectAtIndex:2];
        
        [arrayTrack1 addObject:ob];
        
        [ob release];
        [array release];
        
    }
    
    table = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview: table];
    [arr release];
    [arrfile release];
    */
   }


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //self.view.backgroundColor = RGB(216, 216, 216);
    
    self.navigationItem.title = @"History";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self dealloc];
}
#pragma mark -- table
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return arrayTrack1.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CellCustemTableViewCell *custemCell = (CellCustemTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"mycell"];
    if( custemCell == nil){
        
        custemCell = [[CellCustemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
        
    }
    custemCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    ObjectTrack *object = [arrayTrack1 objectAtIndex:indexPath.row];
    //    NSMutableArray *test = [[NSMutableArray alloc] init];
    //    [test addObject: [object NameImage]];
    //lay anh ve tableview
    custemCell.imgView.image = [UIImage imageNamed:@"mp3.jpg"];
    NSString *strUrl = [[NSString alloc] initWithFormat:@"%@", [object NameImage]];
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"length: %lu",(unsigned long)strUrl.length);
    if (strUrl.length > 10) {
        NSURL *URL = [NSURL URLWithString:strUrl];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        manager.responseSerializer = [AFImageResponseSerializer serializer];
        [manager GET:URL.absoluteString parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            
            custemCell.imgView.image =responseObject;
            
            //[table reloadData];
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
    
    
    //custemCell.imageView.image = [arrayData objectAtIndex:indexPath.row];
    custemCell.lbTitle.text = (NSString *)[object NameSong];
    custemCell.lbTitle2.text = (NSString *)[object NameSinger];
   // custemCell.imgView2.image = [UIImage imageNamed:@"ico_arrow.png"];
   
    return custemCell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return heights/10;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
