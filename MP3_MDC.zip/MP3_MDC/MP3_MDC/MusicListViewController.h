//
//  MusicListViewController.h
//  MP3_MDC
//
//  Created by Duc Thanh on 6/14/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicListViewController : UIViewController
@property (nonatomic, strong) NSMutableArray *mulArrays;
@end
