//
//  AppDelegate.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "AppDelegate.h"
#import "HomeViewController.h"
#import "PlaylistViewController.h"
#import "GenreViewController.h"
#import "SearchViewController.h"
#import "MoreViewController.h"
#import "Setting.h"
#import "History.h"
#import "PlayingViewController.h"
#import "GenreViewController.h"
#import "SearchViewController.h"
#import "ViewController.h"
#import "ListMusicViewController.h"

static AppDelegate *instance;

@interface AppDelegate ()

@end
@implementation AppDelegate
@synthesize window, tabController, homeVC, playlistVC, generVC, searchVC, moreVC, navigation, setting, history, playingVC, naHome, naPlaylist, naGenre, naSearch, list, listMusicVC;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
//    if (![self connectedToInternet]) {
//        UIAlertView *aler = [[UIAlertView alloc] initWithTitle:@"No internet" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
//        [aler show];
//        return NO;
//    }else{
        [self initUI];
        instance = self;
    //}
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark--  private funtion----
- (void) initUI
{    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];//tao man hinh chinh root
    //khoi tao
    self.homeVC = [[HomeViewController alloc] init];
    self.naHome = [[UINavigationController alloc] initWithRootViewController:homeVC];
    self.naHome.tabBarItem.image = [UIImage imageNamed:@"ic_tab_home.png"];
    self.naHome.title = @"Home";
    self.naHome.view.backgroundColor = [UIColor whiteColor];
    
    self.playlistVC = [[PlaylistViewController alloc] init];
    self.playlistVC.tabBarItem.title = @"Playlist";
    self.naPlaylist = [[UINavigationController alloc] initWithRootViewController:playlistVC];
    [self.playingVC loadView];
    self.naPlaylist.view.backgroundColor = [UIColor whiteColor];
    
    self.naPlaylist.tabBarItem.image = [UIImage imageNamed:@"ic_tab_playlist_focused.png"];
    self.naPlaylist.title = @"Playlist";

    self.generVC = [[GenreViewController alloc] init];
    self.naGenre = [[UINavigationController alloc] initWithRootViewController:self.generVC];
    self.naGenre.title = @"Genre";
    self.naGenre.tabBarItem.image = [UIImage imageNamed:@"ic_tab_genre.png"];
    
    self.naGenre.view.backgroundColor = [UIColor whiteColor];

    self.searchVC = [[SearchViewController alloc] init];
    self.naSearch = [[UINavigationController alloc] initWithRootViewController:self.searchVC];
    self.naSearch.title = @"Search";
    self.naSearch.tabBarItem.image = [UIImage imageNamed:@"ic_tab_search_focused.png"];
    self.naSearch.view.backgroundColor = [UIColor whiteColor];

    self.moreVC = [[MoreViewController alloc] init];
    
    self.navigation = [[UINavigationController alloc] initWithRootViewController:moreVC];
    self.navigation.tabBarItem.image = [UIImage imageNamed:@"ic_tab_more.png"];
    self.navigation.title = @"More";
    self.navigation.view.backgroundColor = [UIColor whiteColor];
    

    tabController = [[UITabBarController alloc] init];
    tabController.view.tintColor = [UIColor redColor];
    naHome.view.tintColor = [UIColor blackColor];
    naPlaylist.view.tintColor = [UIColor blackColor];
    tabController.viewControllers = [NSArray arrayWithObjects:naHome, naPlaylist, naGenre, naSearch, navigation, nil];
    
    self.window.rootViewController = tabController; //set cai view tabcontroller tren moi man hinh se lam sau nay
    [window makeKeyAndVisible];
}

#pragma mark --- public functions ---
+(AppDelegate *)sharedInstance {
    return instance;
}

-(void)showSettingVC {
    if([navigation.visibleViewController isKindOfClass:[Setting class]])
        return;
    
    setting = [[Setting alloc] init];
    [navigation pushViewController:setting animated:YES];
    [setting release];
}

-(void)showHistotyVC
{
    if([navigation.visibleViewController isKindOfClass:[History class]])
        return;
    history = [[History alloc] init];
    [navigation pushViewController:history animated:YES];
    [history release];
}

-(void)showPlayMuicVC
{
    //if([naHome.visibleViewController isKindOfClass:[PlayingViewController class]])
      //  return;
    if(playingVC == nil) {
        playingVC = [[PlayingViewController alloc] init];
    }
    [self.tabController presentViewController:playingVC animated:YES completion:nil];
    //[playlistVC release];
}

-(void) hidePlayMusicVC {
    [self.tabController dismissViewControllerAnimated:YES completion:nil];
}

-(void)showPlayList:objectTrc
{
    if([naHome. visibleViewController isKindOfClass:[PlaylistViewController class]])
        return;
    
    playlistVC = [[PlaylistViewController alloc] init];
    
    playlistVC.objectTrc = objectTrc;
    playlistVC.tes = 1;
    [naHome pushViewController:playlistVC animated:YES];
//    [playlistVC release];
    
}

- (void)showPlaying:(NSInteger)bien array:(NSMutableArray *)arr{
    if(playingVC == nil){
        playingVC = [[PlayingViewController alloc] init];
    }
    playingVC.test = bien;
    if(playingVC.arrayTrack == nil){
        playingVC.arrayTrack = arr;
    }
    [playingVC onPlayTrack:bien andArray:arr];
    [self.tabController presentViewController:playingVC animated:YES completion:nil];
   // [playingVC release];
    
}
-(void)showplaying2:(NSInteger)bien array:(NSMutableArray *)arr{
    if(playingVC == nil){
        playingVC = [[PlayingViewController alloc] init];
    }
    playingVC.test = bien;
    if(playingVC.arrayTrack == nil){
        playingVC.arrayTrack = arr;
    }
    [playingVC onPlayTrack:bien andArray:arr];
    [self.tabController presentViewController:playingVC animated:YES completion:nil];


}
-(void) showList: (NSMutableArray *) array{
    list = [[ViewController alloc] init];
    list.arrayTrack = array;
    
   // UINavigationController *naviController = [[UINavigationController alloc] initWithRootViewController:list];
    
    [self.naGenre pushViewController:list animated:YES];
    [self.naGenre release];
    [list release];
}
//-(void) showPlayList{
//    [playlistVC updateList];
//}
-(void) updateList{
    if(playlistVC == nil){
     playlistVC = [[PlaylistViewController alloc] init];
    }
    [playlistVC loadView];
    
}

-(void)showListMusicVC {
    listMusicVC = [[ListMusicViewController alloc] init];
    [self.naGenre pushViewController:listMusicVC animated:YES];
    [listMusicVC release];
}

- (BOOL) connectedToInternet
{
    NSString *URLString = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://www.google.com"] encoding:NSUTF8StringEncoding error:nil];
    return ( URLString != NULL ) ? YES : NO;
}

//-(void)backHome{
//    self.homeVC = [[HomeViewController alloc] init];
//    self.naHome = [[UINavigationController alloc] initWithRootViewController:homeVC];
//    self.naHome.tabBarItem.image = [UIImage imageNamed:@"ic_tab_home.png"];
//    self.naHome.title = @"Home";
//    
//    self.tabController
//}
@end
