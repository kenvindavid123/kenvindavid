//
//  AppDelegate.h
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HomeViewController;
@class PlaylistViewController;
@class GenreViewController;
@class SearchViewController;
@class MoreViewController;
@class Setting;
@class History;
@class PlayingViewController;
@class ObjectTrack;
@class ViewController;
@class ListMusicViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;  //doi tuong root cua windown
@property (assign, nonatomic) UITabBarController *tabController;
@property (assign, nonatomic) HomeViewController *homeVC;
@property (assign, nonatomic) PlaylistViewController *playlistVC;
@property (assign, nonatomic) GenreViewController *generVC;
@property (assign, nonatomic) SearchViewController *searchVC;
@property (assign, nonatomic) MoreViewController *moreVC;
@property (assign, nonatomic) UINavigationController *navigation;
@property (assign, nonatomic) UINavigationController *naHome;
@property (assign, nonatomic) UINavigationController *naPlaylist;
@property (assign, nonatomic) Setting *setting;
@property (assign, nonatomic) History *history;
@property (assign, nonatomic) PlayingViewController *playingVC;
@property (assign, nonatomic) UINavigationController *naGenre;
@property (assign, nonatomic) UINavigationController *naSearch;
@property (assign, nonatomic) ViewController *list;
@property (assign, nonatomic) ListMusicViewController *listMusicVC;

+(AppDelegate *)sharedInstance;
-(void)showSettingVC;
-(void)showHistotyVC;
-(void)showPlayMuicVC;
-(void)showPlayList:(ObjectTrack *)objectTrc;
- (void) showPlaying: (NSInteger) bien array : (NSMutableArray *)arr;
-(void) showplaying2: (NSInteger) bien array : (NSMutableArray *)arr;

-(void) showList: (NSMutableArray *)array;
-(void) hidePlayMusicVC;
-(void) showPlayList;
-(BOOL) connectedToInternet;
-(void) updateList;
- (void) showListMusicVC;

@end

