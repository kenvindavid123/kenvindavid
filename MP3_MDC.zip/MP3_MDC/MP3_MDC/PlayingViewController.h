//
//  PlayingViewController.h
//  MP3_MDC
//
//  Created by Duc Thanh on 4/27/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AVFoundation/AVAudioPlayer.h"
#import "HomeViewController.h"
#import "ObjectTrack.h"
#import "AudioStreamer.h"
@interface PlayingViewController : UIViewController{
    AudioStreamer *musicPlayer ;
}

@property (nonatomic) NSInteger test, bienDK;
@property (nonatomic, assign) NSArray *arrayTrack;


//-(void) onPlayTrack : (NSInteger) bien;
-(void) onPlayTrack : (NSInteger) bien andArray : (NSMutableArray*) arr;

@end
