//
//  ShareAppViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 6/9/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "ShareAppViewController.h"
#import "CellCustemTableViewCell.h"

@interface ShareAppViewController ()<UITableViewDataSource, UITableViewDelegate>{
    UITableView *table;
    int height;
    int width;
}

@end

@implementation ShareAppViewController

- (void)viewDidLoad {
    height = self.view.frame.size.height;
    width = self.view.frame.size.width;
    [super viewDidLoad];
    table = [[UITableView alloc] initWithFrame:CGRectMake(width/20, height/9, width/1.2, height)];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 6;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [table dequeueReusableCellWithIdentifier:@"mycell"];
    if (cell==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
    }
    if (indexPath.row == 0) {
        cell.textLabel.text = @"Facebook";
        cell.imageView.image = [UIImage imageNamed:@"facebook.png"];
    }
    if (indexPath.row == 1) {
        cell.imageView.image = [UIImage imageNamed:@"gmail1.png"];
        cell.textLabel.text = @"Gmail";
    }
    if (indexPath.row == 2) {
        cell.imageView.image = [UIImage imageNamed:@"skyp.jpeg"];
        cell.textLabel.text = @"Skype";
    }
    return cell;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
