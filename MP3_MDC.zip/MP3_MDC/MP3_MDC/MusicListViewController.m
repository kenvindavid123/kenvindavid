//
//  MusicListViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 6/14/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "MusicListViewController.h"
#import "CellCustemTableViewCell.h"
#import "ObjectTrack.h"
#import <AFNetworking/UIImageView+AFNetworking.h>
#import <AFNetworking/AFNetworking.h>
#import "AppDelegate.h"

@interface MusicListViewController ()<UITableViewDelegate, UITableViewDataSource>{
    UITableView *table;
    int heights;
}

@end

@implementation MusicListViewController
@synthesize mulArrays;
#pragma mark ---init
-(void) loadView{
    [super loadView];
    heights = self.view.frame.size.height;
    table = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    //NSLog(@"%lu",[self.mulArray count]);
}
-(void)dealloc{
    [super dealloc];
    [table release];
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    // Do any additional setup after loading the view.
}
#pragma mark --- table

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return (NSInteger)self.mulArrays.count;
    //return  10;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CellCustemTableViewCell *custemCell = (CellCustemTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"mycell"];
    if( custemCell == nil){
        
        custemCell = [[CellCustemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
        
    }
    custemCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    ObjectTrack *object = [self.mulArrays objectAtIndex:indexPath.row];
    //    NSMutableArray *test = [[NSMutableArray alloc] init];
    //    [test addObject: [object NameImage]];
    //lay anh ve tableview
    custemCell.imgView.image = [UIImage imageNamed:@"mp3.jpg"];
    NSString *strUrl = [NSString stringWithFormat:@"%@", [object NameImage]];
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"length: %lu",(unsigned long)strUrl.length);
    if (strUrl.length > 10) {
        NSURL *URL = [NSURL URLWithString:strUrl];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        manager.responseSerializer = [AFImageResponseSerializer serializer];
        [manager GET:URL.absoluteString parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            
            custemCell.imgView.image =responseObject;
            
            //[table reloadData];
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
    
    
       custemCell.lbTitle.text = [object NameSong];
    custemCell.lbTitle2.text = [object NameSinger];
    
    return custemCell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [[AppDelegate sharedInstance] showPlaying:indexPath.row array:self.mulArrays];

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return  heights/10;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
     [self dealloc];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
