
//
//  ViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 5/23/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "ViewController.h"
#import <AFNetworking/UIImageView+AFNetworking.h>
#import "CellCustemTableViewCell.h"
#import "ObjectTrack.h"
#import <AFNetworking/AFNetworking.h>
#import "GenreViewController.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>
{
    UITableView *table;
    NSMutableArray *array;
}
@end

@implementation ViewController
@synthesize arrayTrack;
-(void)loadView{
//    self.navigationItem.title = @"List";
//    self.view.backgroundColor = [UIColor whiteColor];
//    self.navigationItem.title = @"List";
    

}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationItem.title = @"ListMusic";
    table = [[UITableView alloc] init];
    table.frame = self.view.bounds;
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview: table];
    [table release];
    NSLog(@"%lu", self.arrayTrack.count);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.arrayTrack.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CellCustemTableViewCell *cell = [table dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        cell = [[CellCustemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    //ObjectTrack *objecttrack = [[ObjectTrack alloc] init];
    ObjectTrack *objecttrack = [self.arrayTrack objectAtIndex:indexPath.row];
    //lay anh ve tableview
    cell.imgView.image = [UIImage imageNamed:@"mp3.jpg"];
    NSString *strUrl = [[NSString alloc] initWithFormat:@"%@", [objecttrack NameImage]];
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"length: %lu",(unsigned long)strUrl.length);
    if (strUrl.length > 10) {
        NSURL *URL = [NSURL URLWithString:strUrl];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        manager.responseSerializer = [AFImageResponseSerializer serializer];
        [manager GET:URL.absoluteString parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            cell.imgView.image =responseObject;
            
            //[table reloadData];
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
    
    
    //custemCell.imageView.image = [arrayData objectAtIndex:indexPath.row];
    cell.lbTitle.text = [objecttrack NameSong];
    NSLog(@"%@", cell.lbTitle.text);
    cell.lbTitle2.text = [objecttrack NameSinger];
    cell.imgView2.image = [UIImage imageNamed:@"ico_arrow.png"];
    
    return cell;

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
