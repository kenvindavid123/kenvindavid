//
//  PlayingViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/27/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "PlayingViewController.h"
#import "AppDelegate.h"
#import "AVFoundation/AVAudioPlayer.h"
#import "PlayingTableViewCell.h"
#import "AudioStreamer.h"
#import "HomeViewController.h"
#import <AFNetworking/UIImageView+AFNetworking.h>
#import "ObjectTrack.h"
#import <AFNetworking/AFNetworking.h>
//#import "FCFileManager.h"

static NSString *URL = @"?client_id=954240dcf4b7c0a46e59369a69db7215";
@interface PlayingViewController ()<UITableViewDataSource, UITableViewDelegate>

{
    UILabel *lbTitle;
    UIImageView *imgSearch;
    UIImageView *imgBackGround;
    UILabel *lbTimeStart, *lbTimeEnd;
    UITableView *table;
    NSMutableArray *mang;
    UIProgressView *process;
    UIButton *btBack;
    UIButton *btBackImage;
    
    NSMutableArray *nameSong1, *nameSinger1, *nameImage, *nameUrl1 ;
    NSMutableArray *arrayTrack;
    
    UIButton *bt1, *bt2, *bt3, *bt4, *bt5, *bt6;
    
    HomeViewController *hVC;
    
    NSMutableArray *duration;
   // NSMutableArray *nameSong, *nameSinger;
    ObjectTrack *objTrack;
    
    NSURL *urlMS;
    NSTimer *timer;
    double timeStart;
    NSMutableArray *arryTime;
    
    NSInteger durationTime;
    
    NSInteger kiemtra ;
    
    UISlider *slider;
    int width;
    int height;
    
    int phatlap;
    
    Boolean test ;
    
}
@end
@implementation PlayingViewController
@synthesize test = _test, arrayTrack;
#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1];

#pragma mark ---InitUI---

-(void)loadView{
    //height = self.view.frame.size.height;

    [super loadView];
//    if (phatlap ==1) {
//        _test = _test +1;
//    }
    width = self.view.frame.size.width;
    height = self.view.frame.size.height;
    [musicPlayer stop];
    self.view.backgroundColor = [UIColor whiteColor];
    [hVC setBarButton];
    
//    NSLog(@"test = %ld", _test);
//    NSLog(@"array count %lu", self.arrayTrack.count);
    
//  doc du lieu tu file nhac
    
//    
//    nameSong1 = [[NSArray alloc] initWithContentsOfFile:[self getNameFile:@"FileTenBaiHat.txt"]];
//    nameSinger1 = [[NSArray alloc] initWithContentsOfFile:[self getNameFile:@"FileTenCaSi.txt"]];
//    nameUrl1 = [[NSArray alloc] initWithContentsOfFile:[self getNameFile:@"FileTenLinkNhac.txt"]];
//    nameImage = [[NSArray alloc] initWithContentsOfFile:[self getNameFile:@"FileAnh.txt"]];
    
    nameImage = [[NSMutableArray alloc] init];
//    
    for (int i = 0; i< self.arrayTrack.count; i++){
        NSString *image = [[self.arrayTrack objectAtIndex:i] NameImage];
        [nameImage addObject:image];
    
    }
    
  //  NSLog(@"nameimage count = %lu", nameImage.count);
    
    arryTime = [[NSMutableArray alloc] init];
    for (int i = 0; i< self.arrayTrack.count; i++){
        NSString *ti = [[self.arrayTrack objectAtIndex:i] Duration];
        NSInteger inter = [ti integerValue]/1000;
        NSString *ttime = [self getTime:inter];
        [arryTime addObject:ttime];
    }
   
    //arrayTrack = [[NSMutableArray alloc] initWithContentsOfFile:[self getNameFile:@"FileObject.txt"]];
    //NSLog(@"%ld", arrayTrack.count);
    
    UILabel *lbplaying = [[UILabel alloc] initWithFrame:CGRectMake((width - 50)/2,height/52 + 10,width/4, height*4/52)];
    lbplaying.text = @"Playing";
    lbplaying.font = [UIFont boldSystemFontOfSize:15];
    [self.view addSubview:lbplaying];
    [lbplaying release];
    
    imgSearch = [[UIImageView alloc] initWithFrame:CGRectMake(width - 50, height/16, 20, 20)];
    imgSearch.image = [UIImage imageNamed:@"btn_search.png"];
    [self.view addSubview:imgSearch];
    [imgSearch release];
    
    //them nut back
    btBackImage = [[UIButton alloc] initWithFrame:CGRectMake(width/32 , height/16, width/8, height/25)];
    [btBackImage setImage:[UIImage imageNamed:@"btn_back.png"] forState:UIControlStateNormal];
    [btBackImage addTarget:self action:@selector(actionBackImage) forControlEvents:UIControlEventTouchUpInside];
    [btBackImage setTintColor:[UIColor redColor]];
    [self.view addSubview:btBackImage];
    [btBackImage release];
    
//    btBack = [[UIButton alloc] initWithFrame:CGRectMake(32, 25, 80, 30)];
//    //btBack.backgroundColor = [UIColor redColor];
//    [btBack setTitle:@"back" forState:UIControlStateFocused];
//    [btBack setTitleColor:[UIColor redColor] forState:UIControlStateFocused];
//    [btBack addTarget:self action:@selector(actionBack) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btBack];
//    [btBack release] ;
    
//    imgBackGround = [[UIImageView alloc] initWithFrame:CGRectMake(0, 80, self.view.frame.size.width, 150)];
//    imgBackGround.image = [UIImage imageNamed:@"btn_nowplaying@2x.png"];
//    [self.view addSubview:imgBackGround];
    
    imgBackGround = [[UIImageView alloc] initWithFrame:CGRectMake(0, height*7/52, self.view.frame.size.width, height*18/52)];
    
    imgBackGround.image = [UIImage imageNamed:@"mp3.jpg"];
    ObjectTrack *objectMS = [self.arrayTrack objectAtIndex:_test];
    NSString *stringIMG = [NSString stringWithFormat:@"%@", [objectMS NameImage]];
    stringIMG = [stringIMG stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
   // NSLog(@"%lu",stringIMG.length);
    if(stringIMG.length > 10){
        NSString *urlimage = [[self.arrayTrack objectAtIndex:_test] NameImage];
        NSURL *urlMusic = [NSURL URLWithString:urlimage];
        NSData *dataMusic = [[NSData alloc] initWithContentsOfURL:urlMusic];
        imgBackGround.image = [UIImage imageWithData:dataMusic];
        [self.view addSubview:imgBackGround];
    }else{
        [self.view addSubview: imgBackGround];
    }
    [imgBackGround release];
    
    slider = [[UISlider alloc] initWithFrame:CGRectMake(0, height*25/52, width, 20)];
    durationTime = [[[self.arrayTrack objectAtIndex:_test] Duration] integerValue];
    [slider setThumbImage:[UIImage new] forState:UIControlStateNormal];
    slider.maximumValue = 1.0f;
    slider.minimumValue = 0.0f;
    [slider setTintColor:[UIColor redColor]];
    [slider addTarget:self action:@selector(changeValude) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:slider];
    [slider release];
    
    //set su kien chay nhac
    
    //[self managerTime];
    
    //set 2 cai label;
    lbTimeStart = [[UILabel alloc] initWithFrame:CGRectMake(10, height*27/52, 50, 20)];
    lbTimeStart.text = @"00:00";
    lbTimeStart.font = [UIFont systemFontOfSize:10];
    [self.view addSubview: lbTimeStart];
//    [lbTimeStart release];
    
    lbTimeEnd = [[UILabel alloc] initWithFrame:CGRectMake(width*27/32, height*27/52, 50, 20)];
    NSString* stringtime = [[self.arrayTrack objectAtIndex:_test] Duration];
    NSInteger timeduration = [stringtime integerValue]/1000;
    lbTimeEnd.text = [NSString stringWithFormat:@"%@", [self getTime:timeduration - 1]];
    lbTimeEnd.font = [UIFont systemFontOfSize:10];
    [self.view addSubview:lbTimeEnd];
  //  [lbTimeEnd release];
    
    UILabel *tenBH = [[UILabel alloc] initWithFrame:CGRectMake(width*8/32, height*28.5/52, width*16/32, 15)];
    tenBH.text = [[self.arrayTrack objectAtIndex:_test] NameSong];
    tenBH.font = [UIFont systemFontOfSize:12];
    tenBH.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview: tenBH];
    [tenBH release];
    
    UILabel *tenCS = [[UILabel alloc] initWithFrame:CGRectMake(width*10/32, height*30/52,width*12/32, 15)];
    tenCS.text = [[self.arrayTrack objectAtIndex:_test] NameSinger];
    tenCS.textAlignment = NSTextAlignmentCenter;
    tenCS.font = [UIFont systemFontOfSize:10];
    [self.view addSubview:tenCS];
    [tenCS release];
    
    
    UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(0, height*32/52, self.view.frame.size.width, 1)];
    view1.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1];
    [self.view addSubview:view1];
    [view1 release];
    
    //tao nút phat ngau nhien
    bt1 = [[UIButton alloc] initWithFrame:CGRectMake(10, height*33/52, 30, 30)];
    [bt1 setImage:[UIImage imageNamed:@"btn_shuffle@2x.png"] forState:UIControlStateNormal];
    [bt1 addTarget:self action:@selector(randomMusic:) forControlEvents:UIControlEventAllTouchEvents];
    [self.view addSubview: bt1];
    [bt1 release];
    
    //tao nut backplay
    bt2 = [[UIButton alloc] initWithFrame:CGRectMake(width*7/32 + 10, height*33/52, 30, 30)];
    [bt2 setImage:[UIImage imageNamed:@"btn_previous@2x.png"] forState:UIControlStateNormal];
    [bt2 addTarget:self action:@selector(actionBack) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt2];
    [bt2 release];
    
    //tao nut pause
    bt3 = [[UIButton alloc] initWithFrame:CGRectMake(width*15/32, height*33/52, 30, 30)];
    [bt3 setImage:[UIImage imageNamed:@"pause1.png"] forState:UIControlStateNormal];
    [bt3 setHidden:NO];
    [bt3 addTarget:self action:@selector(actionPause) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:bt3];
    [bt3 release];
    
    //tao nut now play
    bt4 = [[UIButton alloc] initWithFrame:CGRectMake(width*15/32, height*33/52, 30, 30)];
    [bt4 setImage:[UIImage imageNamed:@"btn_play.png"] forState:UIControlStateNormal];
    [bt4 addTarget:self action:@selector(actionNowPlay) forControlEvents:UIControlEventTouchUpInside];
    [bt4 setHidden:YES];
    [self.view addSubview:bt4];
    [bt4 release];
    
    //tao nut next
    bt5 = [[UIButton alloc] initWithFrame: CGRectMake(width*23/32 - 10, height*33/52, 30, 30)];
    [bt5 setImage:[UIImage imageNamed:@"btn_next.png"] forState:UIControlStateNormal];
    
    [bt5 addTarget:self action:@selector(actionNext) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview: bt5];
    [bt5 release];
    
    //tao nut
    bt6 = [[UIButton alloc] initWithFrame:CGRectMake(width*28/32, height*33/52, 30, 30)];
    [bt6 setImage:[UIImage imageNamed:@"btn_repeat.png"] forState:UIControlStateNormal];
    [bt6 addTarget:self action:@selector(Repeat) forControlEvents:UIControlEventTouchUpInside];
    if (phatlap == 1) {
        [bt6 setAlpha:0.5];
    }
    [self.view addSubview: bt6];
    [bt6 release];

    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, height*36.5/52, self.view.frame.size.width, 1)];
    view.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1];
    [self.view addSubview:view];
    [view release];
    
    table = [[UITableView alloc] initWithFrame:CGRectMake(0, height*37/52, self.view.frame.size.width, height - height*37/52)];
    table.delegate = self;
    table.dataSource = self;
    table.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:table];
    [table release];
    
//    
   // NSURL *url = [NSURL URLWithString: @"http://api.soundcloud.com/tracks/183224400/stream?client_id=954240dcf4b7c0a46e59369a69db7215"];
    objTrack = [self.arrayTrack objectAtIndex:_test];
    NSString *tt = [objTrack LinkUrl];
    NSString *string = [tt stringByAppendingString:URL];
//    NSLog(@"%ld", (long)_test);
//    NSURL *url = [NSURL URLWithString:string];
    NSURL *url1 = [NSURL URLWithString:string];
    if(musicPlayer.isPlaying){
        [musicPlayer stop];
      //  [musicPlayer release];
    }else{
        [musicPlayer release];
        musicPlayer = [[AudioStreamer alloc] initWithURL:url1];
        //lbTimeEnd.text = [NSString stringWithFormat:@"%lf", totalTime];
        //timeStart = 0;
        [musicPlayer start];
        [self managerTime];

            }
    duration =[[NSMutableArray alloc] init];
    
}
-(void)dealloc
{
    [super dealloc];
    [imgSearch release];
    [nameImage release];
    [arryTime release];
    [musicPlayer release];
    [duration release];
    [arrayTrack release];
    [musicPlayer release];
    
 
     }
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self dealloc];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrayTrack.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PlayingTableViewCell *myCell;
    myCell = [tableView dequeueReusableCellWithIdentifier:@"table"];
    if (myCell == nil) {
        myCell = [[PlayingTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"table"];
    }
    
    myCell.img1.image = [UIImage imageNamed:@"ic_up_arrow.png"];
    myCell.lb1.text = @"21";
    
    //lay du lieu anh
    ObjectTrack *object = [arrayTrack objectAtIndex:indexPath.row];
    myCell.img2.image = [UIImage imageNamed:@"mp3.jpg"];
    NSString *strUrl = [[NSString alloc] initWithFormat:@"%@", [object NameImage]];
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"length: %lu",(unsigned long)strUrl.length);
    if (strUrl.length > 10) {
        NSURL *URL = [NSURL URLWithString:strUrl];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        manager.responseSerializer = [AFImageResponseSerializer serializer];
        [manager GET:URL.absoluteString parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            myCell.img2.image =responseObject;
            
            //[table reloadData];
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
    
    
    myCell.lb2.text = [[arrayTrack objectAtIndex:indexPath.row] NameSong];
    myCell.lb3.text = [[arrayTrack objectAtIndex:indexPath.row] NameSinger];
    myCell.lb4.text = [arryTime objectAtIndex:indexPath.row];
    return myCell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [musicPlayer stop];
    _test = indexPath.row;
    NSString *stringMS = [[[arrayTrack objectAtIndex:indexPath.row] LinkUrl] stringByAppendingString:URL];
    urlMS = [NSURL URLWithString:stringMS];
    if(musicPlayer == nil){
        musicPlayer = [[AudioStreamer alloc] initWithURL:urlMS];
    }else{
        [musicPlayer initWithURL:urlMS];
    }
    [musicPlayer start];
    timeStart = 0;
//    [self managerTime];
    [self loadView];
    
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"HistoryMS.txt"];
    
    
    NSArray *arrfile = [[NSArray alloc] initWithContentsOfFile:filePath];
    NSMutableArray *filearray = [[NSMutableArray alloc] initWithArray:arrfile];
    NSFileManager *manager = [NSFileManager defaultManager];
    // [manager removeItemAtPath:filePath error:nil];
    
    if ([manager createFileAtPath:filePath contents:nil attributes:nil]) {
        NSLog(@"Created the File Successfully.");
        NSLog(@"%@", filePath);
        //NSArray *arrys = [[NSArray alloc] initWithContentsOfFile:filePath];
        
        //NSMutableArray *mularr = [[NSMutableArray alloc] init];
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        ObjectTrack *ob = [arrayTrack objectAtIndex:_test];
        if([[ob NameSong] compare:@""]==0){
            [arr addObject:@"music"];
        }else{
            [arr addObject:[ob NameSong]];
        }
        if([[ob NameSinger] compare:@""]==0){
            [arr addObject:@"singer"];
        }else{
            [arr addObject:[ob NameSinger]];
        }
        
        [arr addObject:[ob NameImage]];
        
        [filearray addObject:arr];
        [filearray writeToFile:filePath atomically:YES];
        
        NSArray *arrs = [[NSArray alloc] initWithContentsOfFile:filePath];
        //                if ([str compare:@""]==1) {
        //                    str = [NSString stringWithFormat:@"%@1%@", str, namesong];
        //                    [str writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
        //                }else{
        //                    [namesong writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
        //                }
        [arr release];
        [arrs release];
        
    } else {
        NSLog(@"Failed to Create the File");
    }
    //[filearray release];
    

    }

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return height/9;
}
-(void) actionPause
{
    [bt3 setHidden:YES];
    [bt4 setHidden:NO];
    [musicPlayer pause];
 //   kiemtra = 1;
//    [self managerTime];
    [self updateTime];
}
-(void) actionNowPlay{
//    kiemtra = 0;
    [bt4 setHidden:YES];
    [bt3 setHidden:NO];
    [musicPlayer start];

    [self managerTime];
    //[self updateTime];
}



//updatetime

-(void) actionSlider{
    
}


-(NSString *) getNameFile: (NSString *)namefile{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:namefile];
    return filePath;
}

-(void) actionNext{
    [timer invalidate];
    timer = nil;
    //timeStart = 0;

    [musicPlayer stop];
    _test = _test +1;
    if(_test >= arrayTrack.count){
        lbTimeStart.text = @"0:0";
        [bt3 setHidden:YES];
        [bt4 setHidden:NO];
        return;

    }
    if(_test < 0 ){
        lbTimeStart.text = @"0:0";
        [bt3 setHidden:YES];
        [bt4 setHidden:NO];
        return;

    }
    lbTimeStart.text = @"0:00";

    [self loadView];
 //   [self playMusic:musicPlayer index:_test];
  //  [self managerTime];
    
}

-(void) actionBack{
    [timer invalidate];
    timer = nil;
    timeStart = 0;
    [musicPlayer stop];
    _test = _test -1;
    if(_test < 0 ){
        //timeStart = 0;
        lbTimeStart.text = @"0:0";
        [bt3 setHidden:YES];
        [bt4 setHidden:NO];
        return;
    }
    if (_test >= arrayTrack.count) {
        lbTimeStart.text = @"0:0";
        [bt3 setHidden:YES];
        [bt4 setHidden:NO];
        return;
    }
     lbTimeStart.text = @"0:00";
    
//    imgBackGround.image = [UIImage imageNamed:@"mp3.png"];
//    ObjectTrack *objectMS = [self.arrayTrack objectAtIndex:_test];
//    NSString *stringIMG = [NSString stringWithFormat:@"%@", [objectMS NameImage]];
//    stringIMG = [stringIMG stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    NSLog(@"%lu",stringIMG.length);
//    if(stringIMG.length > 10){
//        NSString *urlimage = [[self.arrayTrack objectAtIndex:_test] NameImage];
//        NSURL *urlMusic = [NSURL URLWithString:urlimage];
//        NSData *dataMusic = [[NSData alloc] initWithContentsOfURL:urlMusic];
//        imgBackGround.image = [UIImage imageWithData:dataMusic];
//        [self.view addSubview:imgBackGround];
//    }else{
//        [self.view addSubview: imgBackGround];
//    }
//    [imgBackGround release];
    
    
//    [self playMusic:musicPlayer index:_test];
    [self loadView];
//    [self managerTime];
    
}

-(void) playMusic:(AudioStreamer *)music index:(NSUInteger) index{
    [musicPlayer stop];
    //if(index < arrayTrack.count){
        
        NSString *stringMS = [[[arrayTrack objectAtIndex:index] LinkUrl] stringByAppendingString:URL];
        urlMS = [NSURL URLWithString:stringMS];
    if(musicPlayer == nil){
        musicPlayer = [[AudioStreamer alloc] initWithURL:urlMS];
    }else{
        [musicPlayer initWithURL:urlMS];
    }
        [musicPlayer start];
    //}
}
-(void) randomMusic :(AudioStreamer *) music{
    if(!test){
        _test = arc4random() % 6;

        [self loadView];
        [self playMusic: music index:_test];
        bt1.alpha = 0.5;
        test = true;
    }else{
        bt1.alpha = 1;
        test = false;
    }
}

//-(void)onPlayTrack:(ObjectTrack *)obj {
//    objTrack = obj;
//}

//-(void)onPlayTrack:(NSInteger)bien {
//    _test = bien;
//    NSLog(@"_test = %ld", (long)_test);
//}

#pragma mark ---Manager Timer---

-(NSString *) getTime : (int ) milliseconds{
//    NSString *timeTotal  = @"";
//    
//    int hours = (int) (milliseconds / (1000 * 60 * 60));
//    int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
//    int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
//
//    if(hours > 0){
//        timeTotal = [timeTotal stringByAppendingFormat:@"%d", hours];
//    }else{
//        if(minutes > 0){
//            timeTotal = [timeTotal stringByAppendingFormat:@"%d",minutes];
//        }
//        if (minutes<=0) {
//            timeTotal = [timeTotal stringByAppendingString:@"0:0"] ;
//        }
//        if((seconds > 0)&&(seconds>=10)){
//            timeTotal = [[timeTotal stringByAppendingFormat:@":"] stringByAppendingFormat:@"%d", seconds ];
//        }
//        if((seconds > 0)&&(seconds<10)){
//            timeTotal = [[[timeTotal stringByAppendingFormat:@":"] stringByAppendingFormat:@"%d", 0 ] stringByAppendingFormat:@"%d", seconds];
//        }
//    }
    
    int seconds = milliseconds % 60;
    int minutes = (milliseconds / 60) % 60;
    return [NSString stringWithFormat:@"%02d:%02d", minutes, seconds];

    
}
-(void) managerTime{
    if(timer != nil) {
        [timer invalidate];
        timer = nil;
    }
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
    //[musicPlayer start];
    //[slider setValue:0.1];
    [self updateTime];
   
    
}

-(void) updateTime{
    if (musicPlayer.bitRate != 0.0)
    {
        
        
        double progress1 = musicPlayer.progress;
        double duration1 = musicPlayer.duration;
        
        if (duration1>0)
        {
            slider.value = progress1/duration1;
            
            [process setProgressTintColor:[UIColor redColor]];
            lbTimeStart.text = [NSString stringWithFormat:@"%@", [self getTime:progress1]];
        }
        
    }
        if((musicPlayer.progress+1)*1000 >= durationTime ){
            [timer invalidate];
            timer = nil;
            lbTimeStart.text = @"00:00";
            [bt3 setHidden:YES];
            [bt4 setHidden:NO];
            slider.value = 0.0f;
            if (phatlap != 1) {
                _test = _test + 1;
            }
            [self loadView];
        }
    
    

}
-(void) Repeat{
    if(phatlap != 1){
     phatlap = 1;
    [bt6 setAlpha:0.5];

    }else{
        phatlap = 0;
        [bt6 setAlpha:1];
    }
    }
-(void) actionBackImage{
    [[AppDelegate sharedInstance] hidePlayMusicVC];
}

-(void)onPlayTrack:(NSInteger)bien andArray:(NSMutableArray *)arr {
    _test = bien;
    arrayTrack = arr;
    objTrack = [arr objectAtIndex:bien];
    NSString *tt = [objTrack LinkUrl];
    NSString *string = [tt stringByAppendingString:URL];
    //    NSLog(@"%ld", (long)_test);
    NSURL *url = [NSURL URLWithString:string];
    if(musicPlayer.isPlaying){
        [musicPlayer stop];
    }
    if(musicPlayer == nil){
        musicPlayer = [[AudioStreamer alloc] initWithURL:url];
    }else{
        [musicPlayer initWithURL:url];
    }
    //lbTimeEnd.text = [NSString stringWithFormat:@"%lf", totalTime];
    [self loadView];
   // [self managerTime];
    [musicPlayer start];
    
}
-(void) changeValude{
    float t= slider.value;
    double timeStart1 = t*durationTime;
    lbTimeStart.text = [self getTime:timeStart1];
    if (musicPlayer.duration)
    {
        double newSeekTime = t*musicPlayer.duration;
        [musicPlayer seekToTime:newSeekTime];
    }

    
}
- (BOOL) connectedToInternet
{
    NSString *URLString = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://www.google.com"] encoding:NSUTF8StringEncoding error:nil];
    return ( URLString != NULL ) ? YES : NO;
}


@end
