//
//  PlayingTableViewCell.m
//  MP3_MDC
//
//  Created by Duc Thanh on 5/10/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "PlayingTableViewCell.h"
#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1];
@implementation PlayingTableViewCell
@synthesize img1, img2, lb1, lb2, lb3, lb4;

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    int height = [UIScreen mainScreen].bounds.size.height;
    int width = [UIScreen mainScreen].bounds.size.width;
    
    UIColor *color1 = RGB(64, 64, 64);
    UIColor *color2 = RGB(117, 117, 117);
    UIColor *color3 = RGB(216, 216, 216);
    [self setBackgroundColor: color3];
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.img1 = [[UIImageView alloc] initWithFrame:CGRectMake(10, height/10, width/10, width/10)];
    [self addSubview:self.img1];
    
    self.lb1 = [[UILabel alloc] initWithFrame: CGRectMake(10, 24, 18, 18)];
    self.lb1.font = [UIFont systemFontOfSize:height*1.1/60];
    [self addSubview:self.lb1];
    
    self.img2 = [[UIImageView alloc] initWithFrame:CGRectMake(40, 5, 40, 40)];
    [self addSubview:self.img2];
    
    self.lb2 = [[UILabel alloc] initWithFrame:CGRectMake(90, 10,width*20/32, 18)];
    self.lb2.font = [UIFont systemFontOfSize:height*1.6/60];
    [self.lb2 setTextColor:color1];
    [self addSubview:self.lb2];
    
    
    self.lb3 = [[UILabel alloc] initWithFrame:CGRectMake(90, 30, width*20/32, 15  )];
    self.lb3.font = [UIFont systemFontOfSize:height*1.5/60];
    [self.lb3 setTextColor:color2];
    [self addSubview: self.lb3];
    
    self.lb4 = [[UILabel alloc] initWithFrame: CGRectMake(width-60, 40, width*6/32, 10)];
    self.lb4.font = [UIFont systemFontOfSize:height*1.1/60];
    
    [self.lb4 setTextColor:color2];
    [self addSubview: self.lb4];
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
