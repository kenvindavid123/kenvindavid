//
//  MoreViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "MoreViewController.h"
#import "AppDelegate.h"
#import "Setting.h"
#import "History.h"
#import "About.h"
#import "ShareAppViewController.h"
#import "ContactUsViewController.h"
@interface MoreViewController ()<UITableViewDelegate, UITableViewDataSource>
{
    UITableView *table;
    UITableViewCell *cell;
    UILabel *lbTitle;
    UINavigationController *na;
    Setting *setting;
    int width;
    int height;
}


@end

@implementation MoreViewController
#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]
-(void)loadView
{
    [super loadView];
    height = self.view.frame.size.height;
    width = self.view.frame.size.width;
    
    //self.view.backgroundColor = RGB(216, 216, 216);
    self.view.backgroundColor = [UIColor whiteColor];
    
    // Do any additional setup after loading the view.
    lbTitle = [[UILabel alloc] init];
    lbTitle.frame = CGRectMake(0, 0, self.view.frame.size.width, 60);
    [lbTitle setTextAlignment:NSTextAlignmentCenter];
    lbTitle.text = @"More";
    lbTitle.backgroundColor = [UIColor whiteColor];
    lbTitle.font = [UIFont boldSystemFontOfSize:11];
    [self.view addSubview:lbTitle];
    
    table = [[UITableView alloc] initWithFrame:CGRectMake(0, height/9, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
}

-(void)dealloc
{
    [super dealloc];
    [table release];
    [cell release];
    [lbTitle release];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"More";

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self dealloc];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  6;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *name = @"name";
    cell = [table dequeueReusableCellWithIdentifier:name];
        if(cell == nil){
        cell =[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:name];
    }
    if( indexPath.row == 0)
    {
        cell.imageView.image = [UIImage imageNamed:@"ic_menu_setting.png"];
        cell.textLabel.text = @"Setting";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
    }
    if( indexPath.row == 1)
    {
        cell.imageView.image = [UIImage imageNamed:@"ic_menu_history.png"];
        cell.textLabel.text = @"History";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    }
    
    if( indexPath.row == 2)
    {
        cell.imageView.image = [UIImage imageNamed:@"ic_menu_rateapp.png"];
        cell.textLabel.text = @"Rate app";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    }
    
    if( indexPath.row == 3)
    {
        cell.imageView.image = [UIImage imageNamed:@"ic_menu_shareapp.png"];
        cell.textLabel.text = @"Share app";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    }
    
    if( indexPath.row == 4)
    {
        cell.imageView.image = [UIImage imageNamed:@"ic_menu_contact.png"];
        cell.textLabel.text = @"Contact us";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    }
    
    if( indexPath.row == 5)
    {
        cell.imageView.image = [UIImage imageNamed:@"ic_menu_about.png"];
        cell.textLabel.text = @"About";
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    }
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if(indexPath.row == 0)
    {
        NSLog(@"1111");
        [[AppDelegate sharedInstance] showSettingVC];
        
    } else if(indexPath.row == 1) {
        [[AppDelegate sharedInstance] showHistotyVC];
    }
    if (indexPath.row == 3) {
        ShareAppViewController *share = [[ShareAppViewController alloc] init];
        [self.navigationController pushViewController:share animated:YES];
        [share release];
    }
    if (indexPath.row == 4) {
        ContactUsViewController * contac = [[ContactUsViewController alloc] init];
        [self.navigationController pushViewController:contac animated:YES];
        [contac release];
    }
    if(indexPath.row == 5){
        About *about = [[About alloc] init];
        [self.navigationController pushViewController:about animated:YES];
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
