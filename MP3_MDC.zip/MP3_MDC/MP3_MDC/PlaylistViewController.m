//
//  PlaylistViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "PlaylistViewController.h"
#import "CellCustemTableViewCell.h"
#import "AppDelegate.h"
#import "MusicListViewController.h"

@interface PlaylistViewController ()<UITableViewDataSource, UITableViewDelegate, UIAlertViewDelegate, UIActionSheetDelegate>
{
    UILabel *lable;
    UIBarButtonItem *btPlayList, *btAdd;
    UIImageView *img1, *img2;
    UITableView *table;
    UITableViewCell *cell;
    NSMutableArray *mangvidu, *arrayData;;
    NSArray *array;
    NSInteger bien;
    UIAlertView *aler;
    NSString *filePart;
    NSFileManager *fileManager;
    
    NSFileHandle *fileHandle;
    NSInteger testIndex ;
    
   // NSMutableArray *mulArray;
    NSMutableArray *count;
    NSInteger ktra;
    int height;
    
    MusicListViewController *ms;
}

@end

@implementation PlaylistViewController
@synthesize objectTrc, tes;
#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1];
#pragma mark --init
-(void)loadView
{
    
//    PlaylistViewController *playlist = [[PlaylistViewController alloc] init];
    [super loadView];
    
    //[[AppDelegate sharedInstance] updateList];
    
    height = self.view.frame.size.height;
    [self createFileWithName:@"NameList.txt"];
   // [self initParam];
    mangvidu = [[NSMutableArray alloc] init];
    count = [[NSMutableArray alloc] init];
    fileManager = [NSFileManager defaultManager];
    self.view.backgroundColor = [UIColor whiteColor];
    self.tabBarItem.image = [UIImage imageNamed:@"ic_tab_playlist_focused.png"];
    self.navigationItem.title = @"Playlist";
    arrayData = [[NSMutableArray alloc] init];

    if ([fileManager fileExistsAtPath:[self getFilePath:@"List.txt"]]) {
//        NSString *stringNameList = [NSString stringWithContentsOfFile:[self getFilePath:@"List.txt"] encoding:NSUTF8StringEncoding error:nil];
//        NSLog(@"%@", stringNameList);
        NSArray *array1 = [NSArray arrayWithContentsOfFile:[self getFilePath:@"List.txt"]];
        arrayData = [[NSMutableArray alloc] initWithArray:array1];
        for (int i = 0; i < arrayData.count; i++) {
            NSString *stt = [arrayData objectAtIndex:i];
            if(([stt compare:@""] == 0)||(stt == nil)){
                [arrayData removeObjectAtIndex:i];
            }
        }
        [array1 release];

    }
    
    for (int i = 0; i<arrayData.count; i++) {
        NSString *t = [arrayData objectAtIndex:i];
        NSString *filePath = [NSString stringWithFormat:@"%@.txt", t];
        
        NSArray *arr3 = [[NSArray alloc] initWithContentsOfFile:[self getFilePath:filePath]];
        NSString *so = [NSString stringWithFormat:@"%d",(int)arr3.count ];
        [count addObject:so];
    }
    [table reloadData];
    //tao 1 table view
    table = [[UITableView alloc] initWithFrame:CGRectMake(0, height/9, self.view.frame.size.width, height*8/9) style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    [self.view addSubview:table];
    //    [table release];
    [table reloadData];

    
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self updateList];
}

- (void)dealloc
{
    [super dealloc];
   // [lable release];
    [btAdd release];
    [btPlayList release];
    [table release];
    [mangvidu release];
    [arrayData release];
    [count release];
    //[mulArray release];
    
    
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //tao label playlist
    lable = [[UILabel alloc] initWithFrame:CGRectMake(140, 15, 100, 50)];
    lable.text = @"Playlist";
    lable.textColor = RGB(64, 64, 64);
    lable.font = [UIFont systemFontOfSize:11];
    lable.font = [UIFont boldSystemFontOfSize:11];
    [self.view addSubview:lable];
    [lable release];
    
    //tao button play
    //btPlayList = [[UIBarButtonItem alloc ]init ];
    btPlayList = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"btn_nowplaying.png"]
                 style:UIBarButtonItemStyleDone
                 target:self action:@selector(playMusic)];
    
    
    //tao anh add
   btAdd = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"btn_addplaylist.png"]
            style:UIBarButtonItemStyleDone
            target:self action:@selector(showAlerView)];
    
    //tao hanh dong add khi click vao anh add
    
    UIBarButtonItem *btplay = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"btn_nowplaying@2x.png"] style:UIBarButtonItemStyleDone target:self action:@selector(playMusic)];
    NSArray *arrayBt = [NSArray arrayWithObjects:btAdd, btplay, nil];
    self.navigationItem.rightBarButtonItems = arrayBt;
    
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//cau hinh cho table view
#pragma mark --table
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return  1;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrayData.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellCustemTableViewCell *cells = (CellCustemTableViewCell *)[table dequeueReusableCellWithIdentifier:@"baihat"];
    if(cells == nil){
        cells = [[CellCustemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"baihat"];
    }
    cells.imgView.image = [UIImage imageNamed:@"mp3.jpg"];
    cells.lbTitle.text = [arrayData objectAtIndex:indexPath.row];
    cells.lbTitle2.text = [NSString stringWithFormat:@"%@ track",[count objectAtIndex:indexPath.row]];
    cells.imgView2.image = [UIImage imageNamed:@"ico_arrow.png"];
    
    return cells;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return height/10;
}

//khi kich vao 1 cell se hien len actionsheet
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:nil
                                                    cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil
                                                    otherButtonTitles:@"View", @"Rename", @"Delete", nil];
    bien = indexPath.row;
    testIndex = indexPath.row;
    actionSheet.delegate = self;
    if(self.tes != 1 ){
        [actionSheet showInView:self.view];
    }else{
        NSMutableArray *mArray = [[NSMutableArray alloc] init];
        NSString *t = [arrayData objectAtIndex:testIndex];
        NSFileManager *mana = [NSFileManager defaultManager];
        
        NSString *filePath = [self getFilePath:[NSString stringWithFormat:@"%@.txt", t]];
        
        NSArray *arr1 = [[NSArray alloc] initWithContentsOfFile:filePath];
        
        NSMutableArray *mulArr = [[NSMutableArray alloc] init];
        
        NSMutableArray *mulArrName = [[NSMutableArray alloc] init];
        //NSMutableArray *mulArrs = [[NSMutableArray alloc] init];
        
        for (int i = 0; i < arr1.count; i++) {
            [mulArr addObject:[arr1 objectAtIndex:i]];
            NSArray *arr = [arr1 objectAtIndex:i];
            [mulArrName addObject:[arr objectAtIndex:0]];
        }
        
        NSMutableArray *arrayObject = [[NSMutableArray alloc] init];
        NSMutableArray *arrs = [[NSMutableArray alloc] initWithArray:arr1];
        //NSMutableArray *arrs = [[NSMutableArray alloc] init];
        
        int test = 0;

        for (int i = 0; i < mulArrName.count; i++) {
            NSString *stt1 = [NSString stringWithFormat:@"%@", [mulArrName objectAtIndex:i]];
            NSString *stt2 = [NSString stringWithFormat:@"%@", [self.objectTrc NameSong]];
            
            if ([stt2 compare:stt1] == 0) {
                UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"bai hat da co trong playlist" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK ", nil];
                [al show];
                test = 1;
            }
        }
        [mulArrName release];
        if(test != 1){
            [arrayObject addObject:[self.objectTrc NameSong]];
            [arrayObject addObject:[self.objectTrc NameSinger]];
            [arrayObject addObject:[self.objectTrc NameImage]];
            [arrayObject addObject:[self.objectTrc LinkUrl]];
            [arrayObject addObject:[self.objectTrc Duration]];
            [mArray addObject:arrayObject];
            [arrs addObject:arrayObject];
            [mana removeItemAtPath:filePath error:nil];
            [arrs writeToFile:filePath atomically:YES];
            [self loadView];
            //[[AppDelegate sharedInstance] showPlayList];
            [[AppDelegate sharedInstance] updateList];
            [[AppDelegate sharedInstance] hidePlayMusicVC];
        }
        //[[AppDelegate sharedInstance] showPlayList];
        [arrs release];
        [arrayObject release];
        [mArray release];
        [arr1 release];
    }
  //  [mulArray release];
    
    [actionSheet release];
}

//ham thuc hien khi click vao playlist se nhay vao man hinh choi nhac
- (void) playMusic
{
    
    [[AppDelegate sharedInstance] showPlayMuicVC];
}

//ham thuc hien khi kich vao nut add se hien alerview lua chon
#pragma mark --aler
- (void) showAlerView
{
    aler = [[UIAlertView alloc] initWithTitle:@"Create"
                                                   message:@"New playlist" delegate:nil
                                         cancelButtonTitle:@"Cancel"
                                         otherButtonTitles:@"OK", nil];
    aler.delegate = self;
    aler.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *text = [aler textFieldAtIndex:0];
    text.placeholder = @"input";
    [aler show];
    
}

// ham xu li su kien khi bam nut ok trong alerview
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == [alertView cancelButtonIndex]){
        
    }else{
        if(ktra == 1){
            NSString *xau = [aler textFieldAtIndex:0].text;
            
            NSMutableArray *arrdata = [[NSMutableArray alloc]init];
            for (int i = 0; i < arrayData.count; i++) {
                if (i==testIndex) {
                    NSLog(@"Di tennfil");
                    [arrdata addObject:xau];
                    NSString *str2 = [NSString stringWithFormat:@"%@.txt", [arrayData objectAtIndex:testIndex]];
                    NSArray *arr1 = [[NSArray alloc] initWithContentsOfFile:[self getFilePath:str2]];
                    NSMutableArray *muarr = [[NSMutableArray alloc] initWithArray:arr1];
                    NSFileManager *mana = [NSFileManager defaultManager];
                    NSString *str1 = [NSString stringWithFormat:@"%@.txt", xau];
                    [muarr writeToFile:[self getFilePath:str1] atomically:YES];
                    [mana removeItemAtPath:[self getFilePath:[arrayData objectAtIndex:testIndex]] error:nil];
                    
                    [mana release];
                    [muarr release];
                }else{
                    [arrdata addObject:[arrayData objectAtIndex:i]];
                }
            }
            
//            arrayData = [NSMutableArray arrayWithArray:arrdata];
            [arrdata writeToFile:[self getFilePath:@"List.txt"] atomically:YES];
//            NSArray *arrss = [NSArray arrayWithContentsOfFile:[self getFilePath:@"List.txt"]];
//            arrayData = [NSMutableArray arrayWithArray:arrss];
            
            //[arrdata release];
            [self loadView];
            //[table reloadData];

           
        }else{
            NSString *chuoi = [[NSString alloc] initWithFormat:@"%@", [alertView textFieldAtIndex:0].text];
            [arrayData addObject:chuoi];
            [self createFileWithName:[NSString stringWithFormat:@"%@.txt",[aler textFieldAtIndex:0].text]];
            if ([fileManager fileExistsAtPath:[self getFilePath:@"List.txt"]] == NO) {
                [self createFileWithName:@"List.txt"];
            }
            NSArray *arrFile = [[NSArray alloc] initWithContentsOfFile:[self getFilePath:@"List.txt"]];
            NSMutableArray *mArray = [[NSMutableArray alloc] initWithArray:arrFile];
            [mArray addObject:[alertView textFieldAtIndex:0].text];
            [mArray writeToFile:[self getFilePath:@"List.txt"] atomically:YES];
            [chuoi release];
            [arrFile release];
            [mArray release];
            [self loadView];
        }
//        [self loadView];
        
    }
    
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
        {
             NSString *filePath = [NSString stringWithFormat:@"%@.txt", [self getFilePath:[arrayData objectAtIndex:testIndex]]];
            //[mulArray removeAllObjects];
            NSMutableArray *mulArray = [[NSMutableArray alloc] initWithContentsOfFile:filePath];
            //[mangvidu removeAllObjects];
            NSMutableArray *mangvidu1 = [[NSMutableArray alloc] init];
            //NSMutableArray *mangvidu1 = [[NSMutableArray alloc] init];
            for (int i = 0; i < mulArray.count; i++) {
                NSMutableArray *arrays = [mulArray objectAtIndex:i];
                ObjectTrack *obj = [[ObjectTrack alloc] init];
                
                    obj.NameSong = [arrays objectAtIndex:0];
                    obj.NameSinger = [arrays objectAtIndex:1];
                    obj.NameImage = [arrays objectAtIndex:2];
                    obj.LinkUrl = [arrays objectAtIndex:3];
                    obj.Duration = [arrays objectAtIndex:4];
                [mangvidu1 addObject:obj];
                [obj release];
                //[arrays release];
                
            }
                ms = [[MusicListViewController alloc] init];
            //ms.mulArray = [[NSMutableArray alloc] init];
//            if (ms.mulArray != nil) {
//                [ms.mulArray release];
//            }
            //ms.mulArray = [[NSMutableArray alloc] init];
            //if (ms.mulArrays== nil) {
                ms.mulArrays = [[NSMutableArray alloc] initWithArray:mangvidu1];
            //}
            [self.navigationController pushViewController:ms animated:YES];
            [ms release];
            [mulArray release];
            //[ms.mulArrays release];
            //[[AppDelegate sharedInstance] showPlaying:0 array:mangvidu];
            //[mangvidu1 release];
            break;
            
        }
            
        case 1:
        {
            

            [self showAlerView];
            [aler textFieldAtIndex:0].text = [arrayData objectAtIndex:testIndex];
            ktra = 1;
            

            break;
        }

        case 2:
        {
            

            [arrayData removeObjectAtIndex:testIndex];
            [arrayData writeToFile:[self getFilePath:@"List.txt"] atomically:YES];
            [table reloadData];
            break;
        }
        default:
            break;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark --file

- (void)createFileWithName:(NSString *)fileName {
    
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
    
    NSFileManager *manager = [NSFileManager defaultManager];
    
    if ([manager createFileAtPath:filePath contents:nil attributes:nil]) {
        NSLog(@"Created the File Successfully.");
    } else {
        NSLog(@"Failed to Create the File");
    }
}
- (void)createFileWithName:(NSString *)fileName conten:(NSString *)content
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
    
    NSFileManager *manager = [NSFileManager defaultManager];
    
    if ([manager createFileAtPath:filePath contents:nil attributes:nil]) {
        NSLog(@"Created the File Successfully.");
        NSLog(@"%@", filePath);
        [content writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    } else {
        NSLog(@"Failed to Create the File");
    }
    
}
-(NSString *) getFilePath:(NSString *)fileName{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
    return filePath;
}
-(void) updateList{
    arrayData = [[NSMutableArray alloc] init];
    
    if ([fileManager fileExistsAtPath:[self getFilePath:@"List.txt"]]) {
        //        NSString *stringNameList = [NSString stringWithContentsOfFile:[self getFilePath:@"List.txt"] encoding:NSUTF8StringEncoding error:nil];
        //        NSLog(@"%@", stringNameList);
        NSArray *array1 = [NSArray arrayWithContentsOfFile:[self getFilePath:@"List.txt"]];
        arrayData = [[NSMutableArray alloc] initWithArray:array1];
        for (int i = 0; i < arrayData.count; i++) {
            NSString *stt = [arrayData objectAtIndex:i];
            if(([stt compare:@""] == 0)||(stt == nil)){
                [arrayData removeObjectAtIndex:i];
            }
        }
        [array1 release];
        
    }
    [count removeAllObjects];
    for (int i = 0; i<arrayData.count; i++) {
        NSString *t = [arrayData objectAtIndex:i];
        NSString *filePath = [NSString stringWithFormat:@"%@.txt", t];
        
        NSArray *arr3 = [[NSArray alloc] initWithContentsOfFile:[self getFilePath:filePath]];
        NSString *so = [NSString stringWithFormat:@"%d",(int)arr3.count ];
        [count addObject:so];
    }
    [table reloadData];

}

@end
