//
//  Glogbal.h
//  MP3_MDC
//
//  Created by Duc Thanh on 5/30/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <Foundation/Foundation.h>

int timeOut;

extern
