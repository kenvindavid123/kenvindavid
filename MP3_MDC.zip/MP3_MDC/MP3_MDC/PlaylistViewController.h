//
//  PlaylistViewController.h
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ObjectTrack.h"

@interface PlaylistViewController : UIViewController
@property (nonatomic, assign) ObjectTrack *objectTrc;
@property (nonatomic, assign) int tes;
//-(void)addObjectToArray;
@end
