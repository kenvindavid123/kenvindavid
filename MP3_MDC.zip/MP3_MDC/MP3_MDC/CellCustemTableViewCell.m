//
//  CellCustemTableViewCell.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/29/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "CellCustemTableViewCell.h"

@implementation CellCustemTableViewCell
@synthesize imgView, imgView2, lbTitle, lbTitle2;
#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1];


-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    int height = [UIScreen mainScreen].bounds.size.height;
    int width = [UIScreen mainScreen].bounds.size.width;
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
    self.imgView = [[UIImageView alloc] initWithFrame:CGRectMake(width/15, 8, width/9, width/8)];
    self.imgView.contentMode = UIViewContentModeScaleAspectFill;
    [self addSubview:imgView];
    
    self.lbTitle = [[UILabel alloc] initWithFrame:CGRectMake(230*width/1000, height/70, 3*width/6, width/12)];
    self.lbTitle.font = [UIFont systemFontOfSize:height*1.5/60];
    UIColor *color1 = RGB(64, 64, 64);
    [self.lbTitle setTextColor:color1];
    [self addSubview:lbTitle];
    
    self.lbTitle2 = [[UILabel alloc] initWithFrame:CGRectMake(230*width/1000, height/40, 5*width/6, height/12)];
    self.lbTitle2.font = [UIFont systemFontOfSize:height*1.1/60];
 //   self.lbTitle2.tintColor = RGB(245 , 245, 245);
    UIColor *color = RGB(117 , 117, 117);
    [self.lbTitle2 setTextColor:color];
    [self addSubview:lbTitle2];
    
    
//    self.imgView2 = [[UIImageView alloc] initWithFrame:CGRectMake(280, 15, 20, 20)];
//    [self addSubview:imgView2];
    
    return self;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma ---private ---

@end
