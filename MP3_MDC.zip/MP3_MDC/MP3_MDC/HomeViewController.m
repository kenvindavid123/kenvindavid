//
//  HomeViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "HomeViewController.h"
#import "AppDelegate.h"
#import "CellCustemTableViewCell.h"
#import "PlaylistViewController.h"
#import <AFNetworking/UIImageView+AFNetworking.h>
#import "AudioStreamer.h"
#import "FCFileManager.h"
#import "ObjectTrack.h"

@interface HomeViewController ()<UITableViewDelegate, UITableViewDataSource, UIActionSheetDelegate>
{
   
    
    NSMutableArray *nameImage;
    NSMutableArray *nameSinger;
    NSMutableArray *nameSong;
    NSMutableArray *arrayData;
    NSMutableArray *imageLoaded;
    NSMutableArray *duration;
    NSMutableArray *arrayUrlMusic;
    NSMutableArray *arrayImgeView;
    
    ObjectTrack *currentSelectedTrack, *objects;
    
    UITableView *table;
    NSMutableArray *mang;
    UILabel *title;
    UIBarButtonItem *btPlay;
    UITableViewCell *cell;
    
    NSMutableData *webData;
    NSURLConnection *connection;
    AppDelegate *app;
    
    NSDictionary *dictionaty;
    NSDictionary *dicRoot;
    __block NSArray *data;
    NSInteger bien;
    NSMutableArray *arrTruyenDi;
    
    UIAlertView *infor;
   
    
    UIActivityIndicatorView *spinner;
    int height;
    int width;
    
    

}
@end

@implementation HomeViewController
@synthesize loadImageView = _loadImageView, mangLinkNhac;
@synthesize arrTracks = _arrTracks, btPlay, indicator;
#pragma mark --- init
-(void)loadView
{
    [super loadView];
    
    height = self.view.frame.size.height;
    width = self.view.frame.size.width;
    
    duration = [[NSMutableArray alloc] init];
    arrayUrlMusic = [[NSMutableArray alloc] init];
    arrTruyenDi = [[NSMutableArray alloc] init];
    
    [self loadJson];
    
    //NSLog(@"so bai hat: %lu", nameSong.count);
    self.view.backgroundColor = [UIColor whiteColor];
    self.tabBarItem.image = [UIImage imageNamed:@"ic_tab_home_focused.png"];
    self.navigationItem.title = @"Home";
    //set button play tren
//    btPlay = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"btn_nowplaying@2x.png"]
//                                              style:UIBarButtonItemStyleDone
//                                             target:self action:@selector(playMusic1)];
    btPlay  = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"btn_nowplaying@2x.png"] style:UIBarButtonItemStyleDone target:self action:@selector(playMusic1)];
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor blueColor];
    
    
//    [self.navigationItem setRightBarButtonItem:btPlay];
    
    table=[[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    table.delegate=self;
    table.dataSource=self;
    [self.view addSubview: table];
    
    _arrTracks = [[NSMutableArray alloc] init];
    //arrTruyenDi = [[NSArray alloc] init];
    
    
}

-(void)dealloc
{
    [super dealloc];
    [title release];
    [btPlay release];
    [table release];
    [mang release];
    [duration release];
    [arrTruyenDi release];
    [arrayUrlMusic release];
    [data release];
    [_arrTracks release];
    [spinner release];
    
    

}
- (void)viewDidLoad {
    [super viewDidLoad];
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [spinner setCenter:CGPointMake(width/2 - 10,height*25/52)];
    [spinner setColor:[UIColor redColor]];
    [self.view addSubview:spinner];
    [spinner startAnimating];

}

-(void) playMusic1{
    [[AppDelegate sharedInstance] showPlayMuicVC];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self dealloc];
}

#pragma mark --table---
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    return  nameSong.count;
    return _arrTracks.count;
}

//hien thi du lieu
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    CellCustemTableViewCell *custemCell = (CellCustemTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"mycell"];
    if( custemCell == nil){
       
        custemCell = [[CellCustemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
        
    }
    custemCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    ObjectTrack *object = [_arrTracks objectAtIndex:indexPath.row];

//lay anh ve tableview
    custemCell.imgView.image = [UIImage imageNamed:@"mp3.jpg"];
    NSString *strUrl = [NSString stringWithFormat: @"%@", [object NameImage]];
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"length: %lu",(unsigned long)strUrl.length);
    if (strUrl.length > 10) {
        NSURL *URL = [NSURL URLWithString:strUrl];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];

        manager.responseSerializer = [AFImageResponseSerializer serializer];
        [manager GET:URL.absoluteString parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            
            custemCell.imgView.image =responseObject;
            
            //[table reloadData];
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
    
    custemCell.lbTitle.text = [object NameSong];
    custemCell.lbTitle2.text = [object NameSinger];
    return custemCell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return height/10;
    ;
}

// click vao mot row thi hien thong bao ra
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Tap in row: %ld", (long)indexPath.row);
    UIActionSheet  *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:nil cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:
                            @"Play",
                            @"Add to playlist",
                            @"Info",
                            nil];
    actionSheet.delegate = self;
    [actionSheet showInView:self.view];
    //currentSelectedTrack = [arrTracks objectAtIndex:indexPath.row];
    bien = indexPath.row;
    currentSelectedTrack = [_arrTracks objectAtIndex:bien];
    
    //tao file ghi lai lich su
    [actionSheet release];
    
}
#pragma mark actionsheet----
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
        {
//            [[AppDelegate sharedInstance] showPlayMuicVC:currentSelectedTrack];
            [[AppDelegate sharedInstance] showPlaying:bien array:arrTruyenDi];
//            [[AppDelegate sharedInstance] showPlayMuicVC];
            [self.navigationItem setRightBarButtonItem:btPlay];
            
            
            NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            NSString *documentsDirectory = [paths objectAtIndex:0];
            NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"HistoryMS.txt"];
            
           
            NSArray *arrfile = [[NSArray alloc] initWithContentsOfFile:filePath];
             NSMutableArray *filearray = [[NSMutableArray alloc] initWithArray:arrfile];
            NSFileManager *manager = [NSFileManager defaultManager];
            
            if ([manager createFileAtPath:filePath contents:nil attributes:nil]) {
                NSLog(@"Created the File Successfully.");
                NSLog(@"%@", filePath);
                
                NSMutableArray *arr = [[NSMutableArray alloc] init];
               
                ObjectTrack *ob = [_arrTracks objectAtIndex:bien];
                if([[ob NameSong] compare:@""]==0){
                    [arr addObject:@"music"];
                }else{
                    [arr addObject:[ob NameSong]];
                }
                if([[ob NameSinger] compare:@""]==0){
                    [arr addObject:@"singer"];
                }else{
                    [arr addObject:[ob NameSinger]];
                }

                [arr addObject:[ob NameImage]];
                
                [filearray addObject:arr];
                [filearray writeToFile:filePath atomically:YES];
                
                NSArray *arrs = [[NSArray alloc] initWithContentsOfFile:filePath];
                
                [arr release];
                [arrs release];
                
            } else {
                NSLog(@"Failed to Create the File");
            }
            
            [arrfile release];
            [filearray release];

            break;
        }
        
        case 1:
            [[AppDelegate sharedInstance] showPlayList:currentSelectedTrack];
            
            break;
            
        case 2:
            objects = [_arrTracks objectAtIndex:bien];
            NSInteger duration = [[objects Duration] integerValue];
            NSString *string1 = [@"Duration:" stringByAppendingFormat:@"%@", [self getTime:duration]];
            NSString *string2 = [@"Genre: " stringByAppendingFormat:@"%@", [objects NameSinger]];
            NSString *string3 = [objects date];
            NSString *string = [[[[string1 stringByAppendingString:@"\n"]stringByAppendingString:string2] stringByAppendingFormat:@"\n"] stringByAppendingString:string3];
            infor = [[UIAlertView alloc]
                        initWithTitle: [objects NameSong]
                        message: string delegate:self
                        cancelButtonTitle:@"Cancel" otherButtonTitles:nil, nil];
            [infor show];
            break;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
//- (void) initParam
//{
//    mang = [[NSMutableArray alloc] initWithObjects:@"bai hat", @"bai hat",@"bai hat",@"bai hat",@"bai hat",@"bai hat",
//            @"bai hat",@"bai hat",@"bai hat",@"bai hat",@"bai hat",@"bai hat",@"bai hat",@"bai hat",@"bai hat",nil];
//    
//
//}
//ham lay ve json
#pragma mark--Json-----
-(void) loadJson
{
    
   data = [[NSArray alloc] init];
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:@"http://api.soundcloud.com/tracks?q=faded&client_id=b97dd929a67b6331a591685c4b68bd84" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) {
        NSLog(@"%@", responseObject);
        //dictionaty = (NSDictionary *) responseObject;
        data = [responseObject retain];
        NSLog(@"output :%@", dictionaty);
//        NSLog(@"%lu", data.count);
        [self parseJSON];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"error: %@", error);
    }];
    
    
}

-(void) parseJSON{
    
    //name = [[NSArray alloc] init];
    //NSArray *arrayName = [[NSArray alloc] init];
    

    //lay ra mang ten bai hat
    for (int i = 0; i < data.count; i++) {
        ObjectTrack *objectTrack = [[ObjectTrack alloc] init];
        NSObject *object;
        object = [data objectAtIndex: i];
        
        NSString *tenbh = [object valueForKey:@"title"];
        objectTrack.NameSong = tenbh;
       // [nameSong addObject:tenbh];
        
        NSString *tencasi = [object valueForKey:@"genre"];
        objectTrack.NameSinger = tencasi;
        NSLog(@"%@", tencasi);
        //[nameSinger addObject:tencasi];
        
        NSString *linkAnh = [object valueForKey:@"artwork_url"];
        objectTrack.NameImage = linkAnh;
        //[nameImage addObject: linkAnh];
        
        NSString *linkURL = [object valueForKey:@"stream_url"];
        objectTrack.LinkUrl = linkURL;
        //[arrayUrlMusic addObject:linkURL];
        
        NSString *duration = [object valueForKey:@"duration"];
        objectTrack.Duration = duration;
        
        NSObject *user = [object valueForKey:@"user"];
        NSString *string = [user valueForKey:@"last_modified"];
        objectTrack.date = string;
        
        [_arrTracks addObject: objectTrack];
        //[nameSong addObject:tenbh];
        [objectTrack release];
    }
//    NSLog(@"%lu", _arrTracks.count);
    arrTruyenDi = _arrTracks;
    //[self createFileWithName:@"FileObject.txt" arrays:arrTracks];
    [spinner stopAnimating];
    [table reloadData];
    
    
}
#pragma mark file----
- (void)createFileWithName:(NSString *)fileName arrays:(NSMutableArray *)arrays{

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
    
    NSFileManager *manager = [NSFileManager defaultManager];
    
    if ([manager createFileAtPath:filePath contents:nil attributes:nil]) {
        NSLog(@"Created the File Successfully.");
    } else {
        NSLog(@"Failed to Create the File");
    }
   
    if ([manager fileExistsAtPath:filePath]) {
        [arrays writeToFile:filePath atomically:YES];
        NSError *error = nil;
        if (error) {
            NSLog(@"There is an Error: %@", error);
        }
    } else {
        NSLog(@"File %@ doesn't exists", fileName);
    }

    
}

-(NSString *) getNameFile: (NSString *)namefile{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:namefile];
    return filePath;
}
#pragma mark --gettime
-(NSString *) getTime : (NSInteger ) milliseconds{
    NSString *timeTotal  = @"";
    
    int hours = (int) (milliseconds / (1000 * 60 * 60));
    int minutes = (int) (milliseconds % (1000 * 60 * 60)) / (1000 * 60);
    int seconds = (int) ((milliseconds % (1000 * 60 * 60)) % (1000 * 60) / 1000);
    
    if(hours > 0){
        timeTotal = [timeTotal stringByAppendingFormat:@"%d", hours];
    }else{
        if(minutes > 0){
            timeTotal = [timeTotal stringByAppendingFormat:@"%d",minutes];
        }
        if (minutes<=0) {
            timeTotal = [timeTotal stringByAppendingString:@"0"] ;
        }
        if((seconds > 0)&&(seconds>=10)){
            timeTotal = [[timeTotal stringByAppendingFormat:@":"] stringByAppendingFormat:@"%d", seconds ];
        }
        if((seconds > 0)&&(seconds<10)){
            timeTotal = [[[timeTotal stringByAppendingFormat:@":"] stringByAppendingFormat:@"%d", 0 ] stringByAppendingFormat:@"%d", seconds];
        }
    }
    return timeTotal;
}
-(void) setBarButton{
    self.navigationItem.backBarButtonItem = btPlay;
}
@end
