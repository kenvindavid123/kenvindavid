//
//  SearchViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "SearchViewController.h"
#import <AFNetworking/UIImageView+AFNetworking.h>
#import "ObjectTrack.h"
#import "CellCustemTableViewCell.h"
#import "AppDelegate.h"
#import <AFNetworking/AFNetworking.h>
#import "PlayingViewController.h"
#import "HomeViewController.h"

#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1];

@interface SearchViewController ()<UITableViewDelegate, UITableViewDataSource>
{
    UILabel *lbTitle;
    UIButton *btCancel;
    UISearchBar *search;
    UITableView *table;
 //   NSMutableArray *mang;
    NSArray *array;
//    UIView *viewCustem;
    UITextField *textfield;
    
    
    //    ObjectTrack *objectTrack;
    NSMutableArray *arrayTrack;
    NSArray *data;
    NSInteger bien;
    NSString *string;
    
    HomeViewController *hVC;
    PlayingViewController *player;
    
    UIActivityIndicatorView *indicator;
    
    int height;
    int width;
}

@end

@implementation SearchViewController

-(void)loadView
{
    [super loadView];
    
    height = self.view.frame.size.height;
    width = self.view.frame.size.width;
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.prompt = @"Search";
    UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(0, height*3/52, width*26/32, height*3/48)];
    
    //view1.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1];
    
    UIView *view2 =[[UIView alloc] initWithFrame:CGRectMake(0, 0, width*21/32, height*3/52)];
    
    view2.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1];
    view2.layer.cornerRadius = 5;
    
    UIButton *btSearch = [[UIButton alloc] initWithFrame:CGRectMake(0, 2, width*25/320, height*25/520)];
    [btSearch setImage:[UIImage imageNamed:@"ic_tab_search_focused.png"] forState:UIControlStateNormal];
    //btSearch.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1];
    [btSearch addTarget:self action:@selector(actionSearch) forControlEvents:UIControlEventTouchUpInside];
    [view2 addSubview:btSearch];
    
    textfield = [[UITextField alloc] initWithFrame:CGRectMake(width*3/32, 2, width*18/32, height*3/56)];
    textfield.delegate = self;
    textfield.placeholder = @" Search on souncloud";
    textfield.font = [UIFont boldSystemFontOfSize:12];
    [textfield setReturnKeyType:UIReturnKeySearch];
    [textfield becomeFirstResponder];
    string = textfield.text;
    //textfield.backgroundColor =[ UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1];
    [view2 addSubview:textfield];
    
    [view1 addSubview:view2];
    
    btCancel = [[UIButton alloc] init];
    btCancel.frame = CGRectMake(width*22/32, 0, width*6/32, height*25/520);
    btCancel.backgroundColor = nil;
    [btCancel setTitle:@"Cancel" forState:UIControlStateNormal];
    [btCancel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btCancel addTarget:self action:@selector(clickCancel) forControlEvents:UIControlEventTouchUpInside];
    [view1 addSubview:btCancel];
    //[btCancel release];
    
    
    self.navigationItem.titleView = view1;
    [view2 release];
    [view1 release];
    [btSearch release];
    
    //    search = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 35, self.view.frame.size.width-70, 35)];
    //    [search setBarStyle:UIBarStyleDefault];
    //    search.placeholder = @"Search on soundcloud ";
    //    search.backgroundColor = [UIColor whiteColor];
    ////    search.backgroundColor = RGB(216, 216, 216);
    ////    [search setTintColor:[UIColor blackColor]];
    //    [search setKeyboardType:UIKeyboardTypeDefault];
    //    search.delegate = self;
    //    [viewCustem addSubview:search];
    
    
    table = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    //table.hidden = NO;
    [self.view addSubview:table];
    
    
    
//    array = [[NSArray alloc] initWithObjects:@"One", @"Two", @"Three", @"Four", @"Five", nil];
 //   mang = [[NSMutableArray alloc] initWithArray:array];
    arrayTrack = [[NSMutableArray alloc] init];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return height/9;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self actionSearch];
    return YES;
}

-(void)dealloc
{
    [super dealloc];
    [btCancel release];
    [search release];
    [arrayTrack release];
    [table release];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
   // [indicator startAnimating];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self dealloc];
}
- (void) clickCancel
{
    NSLog(@"click cancel");
    textfield.text = @"";
    [textfield resignFirstResponder];
}

//cau hinh table
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrayTrack.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellCustemTableViewCell *cell = [table dequeueReusableCellWithIdentifier:@"mycell"];
    if (cell == nil)
    {
        cell = [[CellCustemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
    }
    
    //ObjectTrack *objecttrack = [[ObjectTrack alloc] init];
    ObjectTrack *objecttrack = [arrayTrack objectAtIndex:indexPath.row];
    //lay anh ve tableview
    cell.imgView.image = [UIImage imageNamed:@"mp3.jpg"];
    NSString *strUrl = [NSString stringWithFormat: @"%@", [objecttrack NameImage]];
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"length: %lu",(unsigned long)strUrl.length);
    if (strUrl.length > 10) {
        NSURL *URL = [NSURL URLWithString:strUrl];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        manager.responseSerializer = [AFImageResponseSerializer serializer];
        [manager GET:URL.absoluteString parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            cell.imgView.image =responseObject;
            
            //[table reloadData];
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
    
    
    //custemCell.imageView.image = [arrayData objectAtIndex:indexPath.row];
    cell.lbTitle.text = [objecttrack NameSong];
    NSLog(@"%@", cell.lbTitle.text);
    cell.lbTitle2.text = [objecttrack NameSinger];
    cell.imgView2.image = [UIImage imageNamed:@"ico_arrow.png"];
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    bien = indexPath.row;
    [[AppDelegate sharedInstance] showPlaying:bien array:arrayTrack];
    //[[AppDelegate sharedInstance] showPlayMuicVC];
    //[[AppDelegate sharedInstance].playingVC onPlayTrack:bien andArray:arrayTrack];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"HistoryMS.txt"];
    
    
    NSArray *arrfile = [[NSArray alloc] initWithContentsOfFile:filePath];
    NSMutableArray *filearray = [[NSMutableArray alloc] initWithArray:arrfile];
    NSFileManager *manager = [NSFileManager defaultManager];
    // [manager removeItemAtPath:filePath error:nil];
    
    if ([manager createFileAtPath:filePath contents:nil attributes:nil]) {
        NSLog(@"Created the File Successfully.");
        NSLog(@"%@", filePath);
        //NSArray *arrys = [[NSArray alloc] initWithContentsOfFile:filePath];
        
        //NSMutableArray *mularr = [[NSMutableArray alloc] init];
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        ObjectTrack *ob = [arrayTrack objectAtIndex:bien];
        if([[ob NameSong] compare:@""]==0){
            [arr addObject:@"music"];
        }else{
            [arr addObject:[ob NameSong]];
        }
        if([[ob NameSinger] compare:@""]==0){
            [arr addObject:@"singer"];
        }else{
            [arr addObject:[ob NameSinger]];
        }
        
        [arr addObject:[ob NameImage]];
        
        [filearray addObject:arr];
        [filearray writeToFile:filePath atomically:YES];
        
       // NSArray *arrs = [[NSArray alloc] initWithContentsOfFile:filePath];
        
//        [arr release];
//        [arrs release];
//        [arrfile release];
        
    } else {
        NSLog(@"Failed to Create the File");
    }
    //[filearray release];
    


    
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


- (void)loadJSOn: (NSString *) s {
    //NSString *tt = s;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:s parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        data = [responseObject retain];
        NSLog(@"%@", data);
        [self parseJSON];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"false");
    }];
    
    
}

-(void) parseJSON{
    [arrayTrack removeAllObjects];
    for (int i = 0; i < data.count; i++) {
        NSObject *object;
        ObjectTrack* objectTrack = [[ObjectTrack alloc] init];
        
        object = [data objectAtIndex:i];
        NSString *title1 = [object valueForKey:@"title"];
        objectTrack.NameSong = title1;
        
        NSString *tencasi = [object valueForKey:@"genre"];
        objectTrack.NameSinger = tencasi;
        
        NSString *linkAnh = [object valueForKey:@"artwork_url"];
        objectTrack.NameImage = linkAnh;
        
        NSString *linkURL = [object valueForKey:@"stream_url"];
        objectTrack.LinkUrl = linkURL;
        
        NSString *duration = [object valueForKey:@"duration"];
        objectTrack.Duration = duration;
        
        [arrayTrack addObject: objectTrack];
        [objectTrack release];
        
    }
    [indicator stopAnimating];
    [table reloadData];
}

-(void) actionSearch{
    indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [indicator setCenter:CGPointMake(width/2 -10,height *25/52)];
    [indicator setColor:[UIColor redColor]];
    [self.view addSubview:indicator];
    [indicator startAnimating];
    [textfield resignFirstResponder];
    NSString *url = [NSString stringWithFormat:@"http://api.soundcloud.com/tracks?q=%@&client_id=b97dd929a67b6331a591685c4b68bd84", textfield.text];
    url = [url stringByReplacingOccurrencesOfString:@" " withString:@"%20"];

    NSLog(@"%@", url);
    [self loadJSOn:url];
   
    //[table reloadData];
    //textfield.text = @"";
    //[string111 release];
}
@end
