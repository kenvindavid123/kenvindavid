//
//  ListMusicViewController.m
//  MP3_MDC
//
//  Created by Duc Thanh on 5/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "ListMusicViewController.h"
#import "PlayingTableViewCell.h"
#import "CellCustemTableViewCell.h"
#import "ObjectTrack.h"
#import <AFNetworking/UIImageView+AFNetworking.h>
#import <AFNetworking/AFNetworking.h>
#import "AppDelegate.h"
@interface ListMusicViewController (){
    UITableView *_tableView;
    NSInteger bien;
    UIActivityIndicatorView *indicator;
    NSString *strUrl;
    NSString *tilte;
}


@end

@implementation ListMusicViewController
@synthesize arrTrack = _arrTrack;
-(void)loadView{
    [super loadView];
 //   self.navigationItem.title = tilte;
//    indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
//    [indicator startAnimating];
    
    _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    if (_arrTrack !=nil) {
        [indicator stopAnimating];
    }
    [_tableView reloadData];
}
//-(void) viewWillDisappear:(BOOL)animated{
//    
//}
-(void) dealloc{
    [super dealloc];
    [_tableView release];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    
//    self.navigationItem.title = self.title;
//    NSLog(@"so phan tu: %lu",_arrTrack.count);
    
   // [_tableView release];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    [self dealloc];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 55;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _arrTrack.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CellCustemTableViewCell *custemCell = (CellCustemTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"mycell"];
    if( custemCell == nil){
        
        custemCell = [[CellCustemTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mycell"];
        
    }
    ObjectTrack *object = [_arrTrack objectAtIndex:indexPath.row];
    //    NSMutableArray *test = [[NSMutableArray alloc] init];
    //    [test addObject: [object NameImage]];
    //lay anh ve tableview
    custemCell.imgView.image = [UIImage imageNamed:@"mp3.png"];
//    strUrl = [[NSString alloc] initWithFormat:@"%@", [object NameImage]];
    strUrl = [NSString  stringWithFormat:@"%@",[object NameImage]];
    strUrl = [strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"length: %lu",(unsigned long)strUrl.length);
    if (strUrl.length > 10) {
        NSURL *URL = [NSURL URLWithString:strUrl];
        
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        
        manager.responseSerializer = [AFImageResponseSerializer serializer];
        [manager GET:URL.absoluteString parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
            //NSLog(@"JSON: %@", responseObject);
            custemCell.imgView.image =responseObject;
            
            //[table reloadData];
        } failure:^(NSURLSessionTask *operation, NSError *error) {
            NSLog(@"Error: %@", error);
        }];
    }
    
    
    //custemCell.imageView.image = [arrayData objectAtIndex:indexPath.row];
    custemCell.lbTitle.text = [object NameSong];
    custemCell.lbTitle2.text = [object NameSinger];
    custemCell.imgView2.image = [UIImage imageNamed:@"ico_arrow.png"];
    return custemCell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    bien= indexPath.row;
    [[AppDelegate sharedInstance] showPlaying:bien array:_arrTrack];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"HistoryMS.txt"];
    
    
    NSArray *arrfile = [[NSArray alloc] initWithContentsOfFile:filePath];
    NSMutableArray *filearray = [[NSMutableArray alloc] initWithArray:arrfile];
    NSFileManager *manager = [NSFileManager defaultManager];
    // [manager removeItemAtPath:filePath error:nil];
    
    if ([manager createFileAtPath:filePath contents:nil attributes:nil]) {
        NSLog(@"Created the File Successfully.");
        NSLog(@"%@", filePath);
        //NSArray *arrys = [[NSArray alloc] initWithContentsOfFile:filePath];
        
        //NSMutableArray *mularr = [[NSMutableArray alloc] init];
        
        NSMutableArray *arr = [[NSMutableArray alloc] init];
        
        ObjectTrack *ob = [_arrTrack objectAtIndex:bien];
        if([[ob NameSong] compare:@""]==0){
            [arr addObject:@"music"];
        }else{
            [arr addObject:[ob NameSong]];
        }
        if([[ob NameSinger] compare:@""]==0){
            [arr addObject:@"singer"];
        }else{
            [arr addObject:[ob NameSinger]];
        }
        
        [arr addObject:[ob NameImage]];
        
        [filearray addObject:arr];
        [filearray writeToFile:filePath atomically:YES];
        
        NSArray *arrs = [[NSArray alloc] initWithContentsOfFile:filePath];
        //                if ([str compare:@""]==1) {
        //                    str = [NSString stringWithFormat:@"%@1%@", str, namesong];
        //                    [str writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
        //                }else{
        //                    [namesong writeToFile:filePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
        //                }
        [arr release];
        [arrs release];
        
    } else {
        NSLog(@"Failed to Create the File");
    }
    //[filearray release];
    

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
