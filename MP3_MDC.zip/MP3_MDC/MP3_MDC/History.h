//
//  History.h
//  MP3_MDC
//
//  Created by Duc Thanh on 4/27/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>


#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

@interface History : UIViewController

@end
