//
//  PlayingTableViewCell.h
//  MP3_MDC
//
//  Created by Duc Thanh on 5/10/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayingTableViewCell : UITableViewCell

@property (assign, nonatomic)    UIImageView *img1;
@property (assign, nonatomic)     UILabel *lb1;
@property (assign, nonatomic)     UIImageView *img2;
@property (assign, nonatomic)     UILabel *lb2, *lb3, *lb4;

@end
