//
//  About.m
//  MP3_MDC
//
//  Created by Duc Thanh on 5/26/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "About.h"

@interface About (){
    UIImageView *imgView;
    UIView *view1;
    int height;
    int width;
}

@end

@implementation About
-(void)loadView{
    [super loadView];
    height = self.view.frame.size.height;
    width = self.view.frame.size.width;
    self.view.backgroundColor = [UIColor colorWithRed:216/255.0 green:216/255.0 blue:216/255.0 alpha:1];
    view1 = [[UIView alloc] initWithFrame:CGRectMake(0, 80, self.view.frame.size.width, 200)];
    view1.backgroundColor = [UIColor whiteColor];
    
    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(width*9/32, height/52, width*13/32, height*13/52)];
    imgView.image = [UIImage imageNamed:@"version.png"];
//    [imgView release];
    [view1 addSubview:imgView];
    [imgView release];
    
    UILabel *lbApp = [[UILabel alloc] initWithFrame:CGRectMake(width*13/32, height*15/52, width*8/32, height*2/52)];
    lbApp.text = @"Name App";
    lbApp.font = [UIFont boldSystemFontOfSize:15];
    [lbApp setTextColor:[UIColor colorWithRed:64/255.0 green:64/255.0 blue:64/255.0 alpha:1]];
    [view1 addSubview:lbApp];
    [lbApp release];
    
    UILabel *lbVeison = [[UILabel alloc] initWithFrame:CGRectMake(width*14/32, height*17/52 , width*6/32, 15)];
    lbVeison.text = @"Version 1.0";
    lbVeison.font = [UIFont systemFontOfSize:10];
    [lbVeison setTextColor:[UIColor colorWithRed:117/255.0 green:117/255.0 blue:117/255.0 alpha:1]];
    [view1 addSubview:lbVeison];
    [lbVeison release];
    
    [self.view addSubview:view1];
    [view1 release];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
