//
//  ViewController.h
//  MP3_MDC
//
//  Created by Duc Thanh on 5/23/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic, assign) NSArray *arrayTrack;

@end
