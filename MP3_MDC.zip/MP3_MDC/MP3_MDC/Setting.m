//
//  Setting.m
//  MP3_MDC
//
//  Created by Duc Thanh on 4/25/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import "Setting.h"
#import "AppDelegate.h"
#import "SliderviewViewController.h"
@interface Setting ()<UITableViewDelegate, UITableViewDataSource>
{
    UITableView *table;
    UITableViewCell *cell;
}
@end
#define RGB(r, g, b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1];
@implementation Setting
-(void)loadView
{
    [super loadView];
    self.navigationItem.title = @"Setting";
    UIBarButtonItem *btBack = [[UIBarButtonItem alloc] initWithTitle:@"Back"
                               style:UIBarButtonItemStyleDone target:self action:nil];
    [self.navigationItem setBackBarButtonItem:btBack];
    
    table = [[UITableView alloc] initWithFrame:CGRectMake(0, 10, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    table.backgroundColor = [UIColor whiteColor];
    [self.view addSubview: table];
}

-(void)dealloc
{
    [super dealloc];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //self.tabBarItem.title = @"Setting";
    self.view.backgroundColor = RGB(216, 216, 216);
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell = [table dequeueReusableCellWithIdentifier:@"detifier'"];
    //cell.backgroundColor = [UIColor whiteColor];
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"detifier"];
        
    }
    if(indexPath.row == 0){
        cell.textLabel.text = @"Connection timout";
    }
    if(indexPath.row == 1)
    {
        cell.textLabel.text = @"Clear all history";
    }
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.row == 0){
        SliderviewViewController *sliderView = [[SliderviewViewController alloc] init];
        
        [self.navigationController pushViewController:sliderView animated:YES];
        
    }
    if (indexPath.row == 1) {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *filePath = [documentsDirectory stringByAppendingPathComponent:@"HistoryMS.txt"];
        
        NSFileManager *manager = [NSFileManager defaultManager];
        
        [manager removeItemAtPath:filePath error:nil];
        UIAlertView *aler = [[UIAlertView alloc] initWithTitle:nil message:@"xoa thanh cong" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
        [aler show];
        [aler release];
        
            }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
