//
//  CellCustemTableViewCell.h
//  MP3_MDC
//
//  Created by Duc Thanh on 4/29/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellCustemTableViewCell : UITableViewCell
@property (assign, nonatomic) UIImageView *imgView;
@property (assign, nonatomic) UILabel *lbTitle;
@property (assign, nonatomic) UILabel *lbTitle2;
@property (assign, nonatomic) UIImageView *imgView2;

@end
