//
//  ObjectTrack.h
//  MP3_MDC
//
//  Created by Duc Thanh on 5/16/16.
//  Copyright © 2016 Duc Thanh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ObjectTrack : NSObject

@property (nonatomic, copy) NSString *NameSong;
@property (nonatomic, copy) NSString *NameSinger;
@property (nonatomic, copy) NSString *Duration;
@property (nonatomic, copy) NSString *LinkUrl;
@property (nonatomic, copy) NSString *NameImage;
@property (nonatomic, copy) NSString *date;

@end
